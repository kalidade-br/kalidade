<?php
/**
 * UniChat Admin - Chat com Sistema de Administração Hierárquica
 * Admin Geral (primeiro usuário) + Vice-Admin
 * Autenticação e autorização 100% server-side
 */

error_reporting(E_ALL);
ini_set('display_errors', '1');
session_start();

define('DB_FILE', __DIR__ . '/unichat.db');
define('MAX_FILE_SIZE', 20 * 1024 * 1024);
define('MAX_IMAGE_SIZE', 10 * 1024 * 1024);
define('MAX_AUDIO_SIZE', 20 * 1024 * 1024);
define('MAX_TEXT_LENGTH', 1000);
define('UPLOAD_DIR', __DIR__ . '/uploads/');
define('AVATAR_DIR', __DIR__ . '/uploads/avatars/');

if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0755, true);
if (!is_dir(AVATAR_DIR)) mkdir(AVATAR_DIR, 0755, true);

function getDB() {
    static $db = null;
    if ($db === null) {
        $db = new PDO('sqlite:' . DB_FILE);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $db->exec("PRAGMA foreign_keys = ON;");
    }
    return $db;
}

function initDB() {
    $db = getDB();

    // Tabela users com roles e controle de ban/mute
    $db->exec("CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        pin TEXT NOT NULL,
        avatar TEXT DEFAULT NULL,
        description TEXT DEFAULT '',
        country TEXT DEFAULT '',
        language TEXT DEFAULT '',
        status TEXT DEFAULT 'online',
        last_seen INTEGER DEFAULT 0,
        created_at INTEGER DEFAULT 0,
        is_banned INTEGER DEFAULT 0,
        banned_until INTEGER DEFAULT 0,
        banned_ip TEXT DEFAULT NULL,
        muted_until INTEGER DEFAULT 0,
        role TEXT DEFAULT 'user' CHECK(role IN ('user','vice_admin','admin'))
    )");

    // Tabela de bans por IP (para ban permanente)
    $db->exec("CREATE TABLE IF NOT EXISTS ip_bans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ip TEXT NOT NULL UNIQUE,
        banned_by INTEGER NOT NULL,
        reason TEXT DEFAULT '',
        banned_at INTEGER DEFAULT 0,
        expires_at INTEGER DEFAULT 0
    )");

    // Tabela de logs de admin (auditoria)
    $db->exec("CREATE TABLE IF NOT EXISTS admin_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        admin_id INTEGER NOT NULL,
        action TEXT NOT NULL,
        target_user_id INTEGER DEFAULT NULL,
        details TEXT DEFAULT '',
        created_at INTEGER DEFAULT 0
    )");

    $db->exec("CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        username TEXT NOT NULL,
        content TEXT NOT NULL,
        type TEXT DEFAULT 'text',
        file_path TEXT DEFAULT NULL,
        file_name TEXT DEFAULT NULL,
        file_size INTEGER DEFAULT 0,
        reply_to INTEGER DEFAULT NULL,
        reply_username TEXT DEFAULT NULL,
        reply_content TEXT DEFAULT NULL,
        created_at INTEGER DEFAULT 0,
        deleted_for_all INTEGER DEFAULT 0
    )");
    $db->exec("CREATE TABLE IF NOT EXISTS message_views (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        message_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        viewed_at INTEGER DEFAULT 0,
        UNIQUE(message_id, user_id)
    )");
    $db->exec("CREATE TABLE IF NOT EXISTS message_deletions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        message_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        deleted_at INTEGER DEFAULT 0,
        UNIQUE(message_id, user_id)
    )");
    $db->exec("CREATE TABLE IF NOT EXISTS chat_settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    )");

    // Configuração padrão: chat aberto
    $db->exec("INSERT OR IGNORE INTO chat_settings (key, value) VALUES ('chat_locked', '0')");

    $db->exec("CREATE INDEX IF NOT EXISTS idx_messages_created ON messages(created_at)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_msg_views ON message_views(message_id)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_msg_del ON message_deletions(message_id, user_id)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_ip_bans ON ip_bans(ip)");
}
initDB();

function getClientIP() {
    $headers = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR'];
    foreach ($headers as $h) {
        if (!empty($_SERVER[$h])) {
            $ips = explode(',', $_SERVER[$h]);
            $ip = trim($ips[0]);
            if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                return $ip;
            }
            return $ip;
        }
    }
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

function isIPBanned($ip) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM ip_bans WHERE ip = ? AND (expires_at = 0 OR expires_at > ?)");
    $stmt->execute([$ip, time()]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function sanitize($str) { return htmlspecialchars(trim($str), ENT_QUOTES, 'UTF-8'); }
function generateToken() { return bin2hex(random_bytes(32)); }
function now() { return time(); }
function formatBytes($size) {
    $units = ['B','KB','MB','GB']; $u = 0;
    while ($size >= 1024 && $u < 3) { $size /= 1024; $u++; }
    return round($size, 2) . ' ' . $units[$u];
}
function formatTime($ts) {
    $diff = time() - $ts;
    if ($diff < 60) return 'agora';
    if ($diff < 3600) return floor($diff/60) . ' min';
    if ($diff < 86400) return floor($diff/3600) . ' h';
    return date('d/m/Y H:i', $ts);
}
function formatLastSeen($ts) {
    $diff = time() - $ts;
    if ($diff < 60) return 'online agora';
    if ($diff < 3600) return 'visto por último há ' . floor($diff/60) . ' min';
    if ($diff < 7200) return 'visto por último há 1 hora';
    if ($diff < 86400) return 'visto por último há ' . floor($diff/3600) . ' horas';
    if ($diff < 172800) return 'visto por último ontem às ' . date('H:i', $ts);
    return 'visto por último ' . date('d/m/Y \à\s H:i', $ts);
}
function formatDateSeparator($ts) {
    $today = strtotime('today');
    $yesterday = strtotime('yesterday');
    if ($ts >= $today) return 'Hoje';
    if ($ts >= $yesterday) return 'Ontem';
    $days = ['Domingo','Segunda-feira','Terça-feira','Quarta-feira','Quinta-feira','Sexta-feira','Sábado'];
    $months = ['','Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
    $date = getdate($ts);
    if (time() - $ts < 604800) return $days[$date['wday']];
    return $date['mday'] . ' de ' . $months[$date['mon']] . ' de ' . $date['year'];
}
function makeLinksClickable($text) {
    return preg_replace('/(https?:\/\/[^\s<]+)/i', '<a href="$1" target="_blank" rel="noopener noreferrer" class="chat-link">$1</a>', $text);
}

// ============================================================
// SISTEMA DE AUTENTICAÇÃO E PERMISSÕES (100% SERVER-SIDE)
// ============================================================
function isLoggedIn() { return isset($_SESSION['user_id']) && $_SESSION['user_id'] > 0; }

function getCurrentUser() {
    if (!isLoggedIn()) return null;
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$user) return null;

    // Verifica ban por tempo
    if ($user['is_banned'] && $user['banned_until'] > 0 && $user['banned_until'] < time()) {
        // Ban expirou, desbanir automaticamente
        $db->prepare("UPDATE users SET is_banned = 0, banned_until = 0, banned_ip = NULL WHERE id = ?")->execute([$user['id']]);
        $user['is_banned'] = 0;
        $user['banned_until'] = 0;
    }

    // Verifica mute por tempo
    if ($user['muted_until'] > 0 && $user['muted_until'] < time()) {
        $db->prepare("UPDATE users SET muted_until = 0 WHERE id = ?")->execute([$user['id']]);
        $user['muted_until'] = 0;
    }

    return $user;
}

function requireAuth() {
    if (!isLoggedIn()) { jsonError('Não autenticado'); }
    $user = getCurrentUser();
    if (!$user) { session_destroy(); jsonError('Sessão inválida'); }
    if ($user['is_banned']) { jsonError('Sua conta está banida'); }
    if (isIPBanned(getClientIP())) { jsonError('Seu IP está banido'); }
    return $user;
}

function requireAdmin() {
    $user = requireAuth();
    if ($user['role'] !== 'admin') { jsonError('Acesso negado: requer Admin Geral'); }
    return $user;
}

function requireViceAdminOrAbove() {
    $user = requireAuth();
    if ($user['role'] !== 'admin' && $user['role'] !== 'vice_admin') { jsonError('Acesso negado: requer Vice-Admin ou superior'); }
    return $user;
}

function requireCanSendMessage() {
    $user = requireAuth();

    // Verifica se usuário está mutado
    if ($user['muted_until'] > time()) {
        $remaining = ceil(($user['muted_until'] - time()) / 60);
        jsonError('Você está silenciado. Aguarde ' . $remaining . ' minutos.');
    }

    // Verifica se chat está trancado e usuário não é admin
    $db = getDB();
    $locked = $db->query("SELECT value FROM chat_settings WHERE key = 'chat_locked'")->fetchColumn();
    if ($locked === '1' && $user['role'] !== 'admin' && $user['role'] !== 'vice_admin') {
        jsonError('O chat está fechado. Apenas admins podem enviar mensagens.');
    }

    return $user;
}

function jsonError($msg) {
    header('Content-Type: application/json');
    echo json_encode(['error' => $msg]);
    exit;
}

function jsonSuccess($data = []) {
    header('Content-Type: application/json');
    echo json_encode(array_merge(['success' => true], $data));
    exit;
}

function logAdminAction($adminId, $action, $targetUserId = null, $details = '') {
    $db = getDB();
    $db->prepare("INSERT INTO admin_logs (admin_id, action, target_user_id, details, created_at) VALUES (?, ?, ?, ?, ?)")
       ->execute([$adminId, $action, $targetUserId, $details, now()]);
}

function updateLastSeen() {
    if (isLoggedIn()) {
        $db = getDB();
        $db->prepare("UPDATE users SET last_seen = ?, status = 'online' WHERE id = ?")->execute([now(), $_SESSION['user_id']]);
    }
}

// ============================================================
// ROTAS DA API
// ============================================================
$action = $_GET['action'] ?? '';

// --- REGISTRO (primeiro usuário vira admin) ---
if ($action === 'register') {
    header('Content-Type: application/json');

    // Verifica ban por IP antes de permitir registro
    if (isIPBanned(getClientIP())) { jsonError('IP banido'); }

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $pin = $_POST['pin'] ?? '';
    $description = trim($_POST['description'] ?? '');
    $country = trim($_POST['country'] ?? '');
    $language = trim($_POST['language'] ?? '');

    if (strlen($username) < 3 || strlen($username) > 20) { jsonError('Usuário deve ter 3-20 caracteres'); }
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) { jsonError('Usuário só pode conter letras, números e _'); }
    if (strlen($password) < 6) { jsonError('Senha deve ter no mínimo 6 caracteres'); }
    if (strlen($pin) < 4 || strlen($pin) > 10) { jsonError('PIN deve ter 4-10 dígitos'); }
    if (!ctype_digit($pin)) { jsonError('PIN deve conter apenas números'); }

    $db = getDB();
    $check = $db->prepare("SELECT id FROM users WHERE username = ?");
    $check->execute([$username]);
    if ($check->fetch()) { jsonError('Usuário já existe'); }

    // Primeiro usuário vira admin geral
    $count = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $role = ($count == 0) ? 'admin' : 'user';

    $avatar = null;
    if (!empty($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
        $f = $_FILES['avatar'];
        if ($f['size'] > MAX_IMAGE_SIZE) { jsonError('Avatar deve ser menor que 10MB'); }
        $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg','jpeg','png','gif','webp'])) { jsonError('Formato de imagem inválido'); }
        $avatarName = uniqid() . '.' . $ext;
        move_uploaded_file($f['tmp_name'], AVATAR_DIR . $avatarName);
        $avatar = $avatarName;
    }

    $db->prepare("INSERT INTO users (username, password_hash, pin, avatar, description, country, language, created_at, role) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")
       ->execute([$username, password_hash($password, PASSWORD_BCRYPT), $pin, $avatar, $description, $country, $language, now(), $role]);

    jsonSuccess(['message' => 'Conta criada! Faça login.', 'role' => $role]);
}

// --- LOGIN ---
if ($action === 'login') {
    header('Content-Type: application/json');
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user || !password_verify($password, $user['password_hash'])) { jsonError('Usuário ou senha incorretos'); }
    if ($user['is_banned']) { jsonError('Conta banida'); }
    if (isIPBanned(getClientIP())) { jsonError('IP banido'); }

    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['token'] = generateToken();
    $db->prepare("UPDATE users SET status = 'online', last_seen = ? WHERE id = ?")->execute([now(), $user['id']]);
    jsonSuccess(['role' => $user['role']]);
}

// --- LOGIN PIN ---
if ($action === 'login_pin') {
    header('Content-Type: application/json');
    $username = trim($_POST['username'] ?? '');
    $pin = $_POST['pin'] ?? '';
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE username = ? AND pin = ?");
    $stmt->execute([$username, $pin]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) { jsonError('Usuário ou PIN incorretos'); }
    if ($user['is_banned']) { jsonError('Conta banida'); }
    if (isIPBanned(getClientIP())) { jsonError('IP banido'); }

    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['token'] = generateToken();
    $db->prepare("UPDATE users SET status = 'online', last_seen = ? WHERE id = ?")->execute([now(), $user['id']]);
    jsonSuccess(['role' => $user['role']]);
}

// --- LOGOUT ---
if ($action === 'logout') {
    if (isLoggedIn()) {
        $db = getDB();
        $db->prepare("UPDATE users SET status = 'offline' WHERE id = ?")->execute([$_SESSION['user_id']]);
    }
    session_destroy();
    jsonSuccess();
}

// --- RECUPERAR SENHA ---
if ($action === 'recover') {
    header('Content-Type: application/json');
    $username = trim($_POST['username'] ?? '');
    $pin = $_POST['pin'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    if (strlen($newPassword) < 6) { jsonError('Nova senha deve ter no mínimo 6 caracteres'); }
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE username = ? AND pin = ?");
    $stmt->execute([$username, $pin]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$user) { jsonError('Usuário ou PIN incorretos'); }
    $db->prepare("UPDATE users SET password_hash = ? WHERE id = ?")->execute([password_hash($newPassword, PASSWORD_BCRYPT), $user['id']]);
    jsonSuccess(['message' => 'Senha alterada com sucesso!']);
}

// --- ENVIAR MENSAGEM ---
if ($action === 'send_message') {
    $user = requireCanSendMessage();
    header('Content-Type: application/json');
    updateLastSeen();

    $content = trim($_POST['content'] ?? '');
    $replyTo = intval($_POST['reply_to'] ?? 0);
    $type = 'text'; $filePath = null; $fileName = null; $fileSize = 0;
    $replyUsername = null; $replyContent = null;

    if ($replyTo > 0) {
        $db = getDB();
        $stmt = $db->prepare("SELECT username, content FROM messages WHERE id = ?");
        $stmt->execute([$replyTo]);
        $replyMsg = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($replyMsg) { $replyUsername = $replyMsg['username']; $replyContent = $replyMsg['content']; }
    }

    if (!empty($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
        $f = $_FILES['file'];
        $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
        $imgExts = ['jpg','jpeg','png','gif','webp','bmp'];
        $audioExts = ['mp3','wav','ogg','m4a','webm'];
        if (in_array($ext, $imgExts)) {
            if ($f['size'] > MAX_IMAGE_SIZE) { jsonError('Imagem deve ser menor que 10MB'); }
            $type = 'image';
        } elseif (in_array($ext, $audioExts)) {
            if ($f['size'] > MAX_AUDIO_SIZE) { jsonError('Áudio deve ser menor que 20MB'); }
            $type = 'audio';
        } else {
            if ($f['size'] > MAX_FILE_SIZE) { jsonError('Arquivo deve ser menor que 20MB'); }
            $type = 'file';
        }
        $safeName = preg_replace('/[^a-zA-Z0-9._-]/', '_', $f['name']);
        $fileName = $safeName; $fileSize = $f['size'];
        $filePath = uniqid() . '_' . $safeName;
        move_uploaded_file($f['tmp_name'], UPLOAD_DIR . $filePath);
    }

    if ($type === 'text') {
        if (strlen($content) === 0 || strlen($content) > MAX_TEXT_LENGTH) { jsonError('Mensagem deve ter 1-1000 caracteres'); }
    }

    $db = getDB();
    $db->prepare("INSERT INTO messages (user_id, username, content, type, file_path, file_name, file_size, reply_to, reply_username, reply_content, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
       ->execute([$user['id'], $user['username'], $content, $type, $filePath, $fileName, $fileSize, $replyTo ?: null, $replyUsername, $replyContent, now()]);
    $msgId = $db->lastInsertId();
    $db->prepare("INSERT OR IGNORE INTO message_views (message_id, user_id, viewed_at) VALUES (?, ?, ?)")->execute([$msgId, $user['id'], now()]);
    jsonSuccess(['message_id' => $msgId]);
}

// --- POLLING UNIFICADO ---
if ($action === 'poll') {
    $user = requireAuth();
    header('Content-Type: application/json');
    updateLastSeen();
    $lastId = intval($_GET['last_id'] ?? 0);
    $db = getDB();

    $stmt = $db->prepare("
        SELECT m.*, u.avatar, u.country, u.language, u.description, u.role,
               (SELECT GROUP_CONCAT(v.user_id) FROM message_views v WHERE v.message_id = m.id) as viewers
        FROM messages m
        JOIN users u ON m.user_id = u.id
        WHERE m.id > ? AND m.deleted_for_all = 0
          AND NOT EXISTS (SELECT 1 FROM message_deletions md WHERE md.message_id = m.id AND md.user_id = ?)
        ORDER BY m.created_at ASC LIMIT 100
    ");
    $stmt->execute([$lastId, $user['id']]);
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($messages as $msg) {
        if ($msg['user_id'] != $user['id']) {
            $db->prepare("INSERT OR IGNORE INTO message_views (message_id, user_id, viewed_at) VALUES (?, ?, ?)")->execute([$msg['id'], $user['id'], now()]);
        }
    }

    $threshold = now() - 60;
    $stmt = $db->prepare("
        SELECT id, username, avatar, status, last_seen, created_at, role 
        FROM users 
        WHERE is_banned = 0 
        ORDER BY 
            CASE WHEN last_seen >= ? THEN 0 ELSE 1 END,
            last_seen DESC,
            username ASC
    ");
    $stmt->execute([$threshold]);
    $allUsers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $onlineCount = count(array_filter($allUsers, fn($u) => $u['last_seen'] >= $threshold));

    // Verifica se chat está trancado
    $chatLocked = $db->query("SELECT value FROM chat_settings WHERE key = 'chat_lock'")->fetchColumn() === '1';

    echo json_encode([
        'messages' => $messages,
        'user_id' => $user['id'],
        'user_role' => $user['role'],
        'all_users' => $allUsers,
        'online_count' => $onlineCount,
        'chat_locked' => $chatLocked,
        'muted_until' => $user['muted_until'] > time() ? $user['muted_until'] : 0
    ]);
    exit;
}

// --- GET MESSAGES ---
if ($action === 'get_messages') {
    $user = requireAuth();
    header('Content-Type: application/json');
    updateLastSeen();
    $lastId = intval($_GET['last_id'] ?? 0);
    $db = getDB();
    $stmt = $db->prepare("
        SELECT m.*, u.avatar, u.country, u.language, u.description, u.role,
               (SELECT GROUP_CONCAT(v.user_id) FROM message_views v WHERE v.message_id = m.id) as viewers
        FROM messages m
        JOIN users u ON m.user_id = u.id
        WHERE m.id > ? AND m.deleted_for_all = 0
          AND NOT EXISTS (SELECT 1 FROM message_deletions md WHERE md.message_id = m.id AND md.user_id = ?)
        ORDER BY m.created_at ASC LIMIT 100
    ");
    $stmt->execute([$lastId, $user['id']]);
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($messages as $msg) {
        if ($msg['user_id'] != $user['id']) {
            $db->prepare("INSERT OR IGNORE INTO message_views (message_id, user_id, viewed_at) VALUES (?, ?, ?)")->execute([$msg['id'], $user['id'], now()]);
        }
    }
    echo json_encode(['messages' => $messages, 'user_id' => $user['id'], 'user_role' => $user['role']]);
    exit;
}

// --- GET VIEWS ---
if ($action === 'get_views') {
    $user = requireAuth();
    header('Content-Type: application/json');
    $msgId = intval($_GET['message_id'] ?? 0);
    $db = getDB();
    $stmt = $db->prepare("SELECT user_id FROM messages WHERE id = ?");
    $stmt->execute([$msgId]);
    $msg = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$msg || ($msg['user_id'] != $user['id'] && $user['role'] === 'user')) { jsonError('Acesso negado'); }
    $stmt = $db->prepare("
        SELECT u.username, u.avatar, v.viewed_at FROM message_views v
        JOIN users u ON v.user_id = u.id
        WHERE v.message_id = ? AND v.user_id != ? ORDER BY v.viewed_at DESC
    ");
    $stmt->execute([$msgId, $msg['user_id']]);
    $views = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['views' => $views]);
    exit;
}

// --- DELETE MESSAGE ---
if ($action === 'delete_message') {
    $user = requireAuth();
    header('Content-Type: application/json');
    $msgId = intval($_POST['message_id'] ?? 0);
    $forAll = isset($_POST['for_all']) && $_POST['for_all'] === '1';
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM messages WHERE id = ?");
    $stmt->execute([$msgId]);
    $msg = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$msg) { jsonError('Mensagem não encontrada'); }

    if ($forAll) {
        // Admin pode deletar qualquer msg, vice-admin também, usuário só a própria
        if ($user['role'] === 'user' && $msg['user_id'] != $user['id']) { jsonError('Você só pode deletar suas próprias mensagens'); }
        $db->prepare("UPDATE messages SET deleted_for_all = 1 WHERE id = ?")->execute([$msgId]);
        if ($msg['user_id'] != $user['id']) {
            logAdminAction($user['id'], 'delete_message', $msg['user_id'], 'Msg ID: ' . $msgId);
        }
    } else {
        $db->prepare("INSERT OR IGNORE INTO message_deletions (message_id, user_id, deleted_at) VALUES (?, ?, ?)")->execute([$msgId, $user['id'], now()]);
    }
    jsonSuccess();
}

// ============================================================
// ROTAS DE ADMINISTRAÇÃO
// ============================================================

// --- ADMIN: Listar todos usuários (para painel) ---
if ($action === 'admin_list_users') {
    $admin = requireAdmin();
    header('Content-Type: application/json');
    $db = getDB();
    $stmt = $db->query("SELECT id, username, avatar, description, country, language, status, last_seen, created_at, is_banned, banned_until, muted_until, role, banned_ip FROM users ORDER BY created_at ASC");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['users' => $users]);
    exit;
}

// --- ADMIN: Editar qualquer usuário ---
if ($action === 'admin_edit_user') {
    $admin = requireAdmin();
    header('Content-Type: application/json');

    $targetId = intval($_POST['user_id'] ?? 0);
    if ($targetId === $admin['id']) { jsonError('Não pode editar a si mesmo por aqui'); }

    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$targetId]);
    $target = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$target) { jsonError('Usuário não encontrado'); }

    $fields = [];
    $params = [];

    if (isset($_POST['username'])) { $fields[] = "username = ?"; $params[] = trim($_POST['username']); }
    if (isset($_POST['password']) && strlen($_POST['password']) >= 6) { $fields[] = "password_hash = ?"; $params[] = password_hash($_POST['password'], PASSWORD_BCRYPT); }
    if (isset($_POST['pin']) && ctype_digit($_POST['pin']) && strlen($_POST['pin']) >= 4) { $fields[] = "pin = ?"; $params[] = $_POST['pin']; }
    if (isset($_POST['description'])) { $fields[] = "description = ?"; $params[] = trim($_POST['description']); }
    if (isset($_POST['country'])) { $fields[] = "country = ?"; $params[] = trim($_POST['country']); }
    if (isset($_POST['language'])) { $fields[] = "language = ?"; $params[] = trim($_POST['language']); }
    if (isset($_POST['role']) && in_array($_POST['role'], ['user','vice_admin','admin'])) { 
        $fields[] = "role = ?"; $params[] = $_POST['role']; 
    }

    if (count($fields) === 0) { jsonError('Nenhum campo para atualizar'); }

    $params[] = $targetId;
    $db->prepare("UPDATE users SET " . implode(', ', $fields) . " WHERE id = ?")->execute($params);

    logAdminAction($admin['id'], 'edit_user', $targetId, json_encode(array_keys($_POST)));
    jsonSuccess(['message' => 'Usuário atualizado']);
}

// --- ADMIN & VICE-ADMIN: Banir usuário ---
if ($action === 'admin_ban_user') {
    $user = requireViceAdminOrAbove();
    header('Content-Type: application/json');

    $targetId = intval($_POST['user_id'] ?? 0);
    $duration = intval($_POST['duration'] ?? 0); // minutos, 0 = permanente
    $banIP = isset($_POST['ban_ip']) && $_POST['ban_ip'] === '1';

    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$targetId]);
    $target = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$target) { jsonError('Usuário não encontrado'); }
    if ($target['role'] === 'admin') { jsonError('Não pode banir o Admin Geral'); }
    if ($user['role'] === 'vice_admin' && $target['role'] === 'vice_admin') { jsonError('Vice-admin não pode banir outro vice-admin'); }

    $bannedUntil = ($duration > 0) ? now() + ($duration * 60) : 0;
    $db->prepare("UPDATE users SET is_banned = 1, banned_until = ? WHERE id = ?")->execute([$bannedUntil, $targetId]);

    // Ban por IP (apenas admin pode banir IP permanentemente)
    if ($banIP && $user['role'] === 'admin') {
        // Pega IP do usuário alvo via last_seen (não temos IP salvo, salvamos agora)
        // Na prática real, o IP seria salvo no login. Aqui simulamos.
        $db->prepare("UPDATE users SET banned_ip = ? WHERE id = ?")->execute([getClientIP(), $targetId]);
        $db->prepare("INSERT OR REPLACE INTO ip_bans (ip, banned_by, reason, banned_at, expires_at) VALUES (?, ?, ?, ?, ?)")
           ->execute([getClientIP(), $user['id'], 'Ban admin', now(), $bannedUntil]);
    }

    logAdminAction($user['id'], 'ban_user', $targetId, 'Duration: ' . $duration . 'min, IP: ' . ($banIP ? 'yes' : 'no'));
    jsonSuccess(['message' => 'Usuário banido']);
}

// --- ADMIN: Desbanir usuário ---
if ($action === 'admin_unban_user') {
    $user = requireViceAdminOrAbove();
    header('Content-Type: application/json');

    $targetId = intval($_POST['user_id'] ?? 0);
    $db = getDB();
    $db->prepare("UPDATE users SET is_banned = 0, banned_until = 0, banned_ip = NULL WHERE id = ?")->execute([$targetId]);

    // Remove IP ban associado (admin only)
    if ($user['role'] === 'admin') {
        $stmt = $db->prepare("SELECT banned_ip FROM users WHERE id = ?");
        $stmt->execute([$targetId]);
        $ip = $stmt->fetchColumn();
        if ($ip) {
            $db->prepare("DELETE FROM ip_bans WHERE ip = ?")->execute([$ip]);
        }
    }

    logAdminAction($user['id'], 'unban_user', $targetId);
    jsonSuccess(['message' => 'Usuário desbanido']);
}

// --- ADMIN & VICE-ADMIN: Silenciar usuário ---
if ($action === 'admin_mute_user') {
    $user = requireViceAdminOrAbove();
    header('Content-Type: application/json');

    $targetId = intval($_POST['user_id'] ?? 0);
    $duration = intval($_POST['duration'] ?? 0); // minutos, 0 = permanente

    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$targetId]);
    $target = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$target) { jsonError('Usuário não encontrado'); }
    if ($target['role'] === 'admin') { jsonError('Não pode silenciar o Admin Geral'); }
    if ($user['role'] === 'vice_admin' && $target['role'] === 'vice_admin') { jsonError('Vice-admin não pode silenciar outro vice-admin'); }

    $mutedUntil = ($duration > 0) ? now() + ($duration * 60) : 9999999999;
    $db->prepare("UPDATE users SET muted_until = ? WHERE id = ?")->execute([$mutedUntil, $targetId]);

    logAdminAction($user['id'], 'mute_user', $targetId, 'Duration: ' . $duration . 'min');
    jsonSuccess(['message' => 'Usuário silenciado']);
}

// --- ADMIN & VICE-ADMIN: Dessilenciar usuário ---
if ($action === 'admin_unmute_user') {
    $user = requireViceAdminOrAbove();
    header('Content-Type: application/json');

    $targetId = intval($_POST['user_id'] ?? 0);
    $db = getDB();
    $db->prepare("UPDATE users SET muted_until = 0 WHERE id = ?")->execute([$targetId]);

    logAdminAction($user['id'], 'unmute_user', $targetId);
    jsonSuccess(['message' => 'Silêncio removido']);
}

// --- ADMIN: Fechar/Abrir chat ---
if ($action === 'admin_toggle_chat') {
    $admin = requireAdmin();
    header('Content-Type: application/json');

    $db = getDB();
    $current = $db->query("SELECT value FROM chat_settings WHERE key = 'chat_locked'")->fetchColumn();
    $newValue = ($current === '1') ? '0' : '1';
    $db->prepare("UPDATE chat_settings SET value = ? WHERE key = 'chat_locked'")->execute([$newValue]);

    logAdminAction($admin['id'], 'toggle_chat', null, 'Locked: ' . $newValue);
    jsonSuccess(['locked' => $newValue === '1']);
}

// --- ADMIN: Apagar mensagem de outro usuário ---
if ($action === 'admin_delete_message') {
    $user = requireViceAdminOrAbove();
    header('Content-Type: application/json');

    $msgId = intval($_POST['message_id'] ?? 0);
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM messages WHERE id = ?");
    $stmt->execute([$msgId]);
    $msg = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$msg) { jsonError('Mensagem não encontrada'); }
    if ($msg['user_id'] == $user['id']) { jsonError('Use a função normal para apagar suas mensagens'); }

    // Vice-admin não pode apagar mensagens de admin
    $stmt = $db->prepare("SELECT role FROM users WHERE id = ?");
    $stmt->execute([$msg['user_id']]);
    $authorRole = $stmt->fetchColumn();
    if ($user['role'] === 'vice_admin' && $authorRole === 'admin') { jsonError('Vice-admin não pode apagar mensagens do Admin Geral'); }

    $db->prepare("UPDATE messages SET deleted_for_all = 1 WHERE id = ?")->execute([$msgId]);
    logAdminAction($user['id'], 'delete_message', $msg['user_id'], 'Msg ID: ' . $msgId);
    jsonSuccess(['message' => 'Mensagem apagada']);
}

// --- ADMIN: Promover/Rebaixar cargo ---
if ($action === 'admin_set_role') {
    $admin = requireAdmin();
    header('Content-Type: application/json');

    $targetId = intval($_POST['user_id'] ?? 0);
    $newRole = $_POST['role'] ?? '';
    if (!in_array($newRole, ['user', 'vice_admin', 'admin'])) { jsonError('Cargo inválido'); }
    if ($targetId == $admin['id']) { jsonError('Não pode alterar seu próprio cargo'); }

    $db = getDB();
    $db->prepare("UPDATE users SET role = ? WHERE id = ?")->execute([$newRole, $targetId]);
    logAdminAction($admin['id'], 'set_role', $targetId, 'New role: ' . $newRole);
    jsonSuccess(['message' => 'Cargo atualizado para ' . $newRole]);
}

// --- ADMIN: Logs de auditoria ---
if ($action === 'admin_logs') {
    $admin = requireAdmin();
    header('Content-Type: application/json');
    $db = getDB();
    $stmt = $db->query("SELECT l.*, a.username as admin_name, t.username as target_name FROM admin_logs l LEFT JOIN users a ON l.admin_id = a.id LEFT JOIN users t ON l.target_user_id = t.id ORDER BY l.created_at DESC LIMIT 200");
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['logs' => $logs]);
    exit;
}

// --- ADMIN: Estatísticas ---
if ($action === 'admin_stats') {
    $admin = requireAdmin();
    header('Content-Type: application/json');
    $db = getDB();
    $stats = [
        'total_users' => $db->query("SELECT COUNT(*) FROM users")->fetchColumn(),
        'total_messages' => $db->query("SELECT COUNT(*) FROM messages")->fetchColumn(),
        'banned_users' => $db->query("SELECT COUNT(*) FROM users WHERE is_banned = 1")->fetchColumn(),
        'online_users' => $db->query("SELECT COUNT(*) FROM users WHERE last_seen >= " . (now() - 60))->fetchColumn(),
        'chat_locked' => $db->query("SELECT value FROM chat_settings WHERE key = 'chat_locked'")->fetchColumn() === '1'
    ];
    echo json_encode($stats);
    exit;
}

// --- ADMIN: Apagar avatar de usuário ---
if ($action === 'admin_delete_avatar') {
    $admin = requireAdmin();
    header('Content-Type: application/json');

    $targetId = intval($_POST['user_id'] ?? 0);
    $db = getDB();
    $stmt = $db->prepare("SELECT avatar FROM users WHERE id = ?");
    $stmt->execute([$targetId]);
    $avatar = $stmt->fetchColumn();
    if ($avatar && file_exists(AVATAR_DIR . $avatar)) {
        unlink(AVATAR_DIR . $avatar);
    }
    $db->prepare("UPDATE users SET avatar = NULL WHERE id = ?")->execute([$targetId]);
    logAdminAction($admin['id'], 'delete_avatar', $targetId);
    jsonSuccess(['message' => 'Avatar removido']);
}

// ============================================================
// ROTAS EXISTENTES (PERFIL, ARQUIVOS, ETC)
// ============================================================

if ($action === 'get_profile') {
    $user = requireAuth();
    header('Content-Type: application/json');
    $userId = intval($_GET['user_id'] ?? 0);
    if ($userId === 0) $userId = $_SESSION['user_id'];
    $db = getDB();
    $stmt = $db->prepare("SELECT id, username, avatar, description, country, language, status, last_seen, created_at, role FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $profile = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$profile) { jsonError('Usuário não encontrado'); }
    echo json_encode(['profile' => $profile]);
    exit;
}

if ($action === 'update_profile') {
    $user = requireAuth();
    header('Content-Type: application/json');
    updateLastSeen();

    $description = trim($_POST['description'] ?? '');
    $country = trim($_POST['country'] ?? '');
    $language = trim($_POST['language'] ?? '');
    $avatar = $user['avatar'];

    if (!empty($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
        $f = $_FILES['avatar'];
        if ($f['size'] > MAX_IMAGE_SIZE) { jsonError('Avatar deve ser menor que 10MB'); }
        $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg','jpeg','png','gif','webp'])) { jsonError('Formato de imagem inválido'); }
        $avatarName = uniqid() . '.' . $ext;
        move_uploaded_file($f['tmp_name'], AVATAR_DIR . $avatarName);
        $avatar = $avatarName;
    }

    $db = getDB();
    $db->prepare("UPDATE users SET description = ?, country = ?, language = ?, avatar = ? WHERE id = ?")
       ->execute([$description, $country, $language, $avatar, $user['id']]);
    jsonSuccess(['avatar' => $avatar]);
}

if ($action === 'all_users') {
    requireAuth();
    header('Content-Type: application/json');
    updateLastSeen();
    $db = getDB();
    $threshold = now() - 60;
    $stmt = $db->prepare("
        SELECT id, username, avatar, status, last_seen, created_at, role 
        FROM users 
        WHERE is_banned = 0 
        ORDER BY 
            CASE WHEN last_seen >= ? THEN 0 ELSE 1 END,
            last_seen DESC,
            username ASC
    ");
    $stmt->execute([$threshold]);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['users' => $users]);
    exit;
}

if ($action === 'online_users') {
    requireAuth();
    header('Content-Type: application/json');
    updateLastSeen();
    $db = getDB();
    $threshold = now() - 60;
    $stmt = $db->prepare("SELECT id, username, avatar, status, role FROM users WHERE last_seen >= ? ORDER BY username");
    $stmt->execute([$threshold]);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['users' => $users]);
    exit;
}

if ($action === 'file') {
    $file = basename($_GET['f'] ?? '');
    $path = UPLOAD_DIR . $file;
    if (file_exists($path)) {
        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        $mime = 'application/octet-stream';
        if (in_array($ext, ['jpg','jpeg'])) $mime = 'image/jpeg';
        elseif ($ext === 'png') $mime = 'image/png';
        elseif ($ext === 'gif') $mime = 'image/gif';
        elseif ($ext === 'webp') $mime = 'image/webp';
        elseif ($ext === 'mp3') $mime = 'audio/mpeg';
        elseif ($ext === 'wav') $mime = 'audio/wav';
        elseif ($ext === 'ogg') $mime = 'audio/ogg';
        header('Content-Type: ' . $mime);
        header('Content-Length: ' . filesize($path));
        header('Cache-Control: public, max-age=86400');
        readfile($path);
    } else { http_response_code(404); echo 'Arquivo não encontrado'; }
    exit;
}

if ($action === 'avatar') {
    $file = basename($_GET['f'] ?? '');
    $path = AVATAR_DIR . $file;
    if (file_exists($path)) {
        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        $mime = 'image/jpeg';
        if ($ext === 'png') $mime = 'image/png';
        elseif ($ext === 'gif') $mime = 'image/gif';
        elseif ($ext === 'webp') $mime = 'image/webp';
        header('Content-Type: ' . $mime);
        header('Content-Length: ' . filesize($path));
        header('Cache-Control: public, max-age=86400');
        readfile($path);
    } else {
        header('Content-Type: image/svg+xml');
        echo '<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"><rect width="100" height="100" fill="#ddd"/><text x="50" y="55" text-anchor="middle" font-size="40" fill="#999">?</text></svg>';
    }
    exit;
}

if ($action === 'ping') {
    requireAuth();
    updateLastSeen();
    header('Content-Type: application/json');
    echo json_encode(['ok' => true]);
    exit;
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, viewport-fit=cover">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#075E54">
<title>WhatsApp Chat</title>


</head>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--wa-green:#25D366;--wa-dark:#075E54;--wa-teal:#128C7E;--wa-light:#DCF8C6;--bg-chat:#E5DDD5;--bg-dark:#0F1419;--bg-input:#F0F2F5;--bg-white:#FFFFFF;--msg-me:#DCF8C6;--msg-other:#FFFFFF;--msg-dark-me:#005C4B;--msg-dark-other:#202C33;--text-primary:#111B21;--text-secondary:#667781;--text-dark:#E9EDEF;--text-muted:#8696A0;--online:#00A884;--offline:#8696A0;--danger:#EA0038;--warning:#FFB800;--info:#53BDEB;--admin-gold:#FFD700;--admin-gold-dark:#B8860B;--vice-purple:#9B59B6;--vice-purple-dark:#7D3C98;--border-light:#E9EDEF;--border-dark:#2A3942;--shadow-sm:0 1px 2px rgba(0,0,0,0.08);--shadow-md:0 4px 12px rgba(0,0,0,0.15);--shadow-lg:0 8px 30px rgba(0,0,0,0.25);--radius-sm:6px;--radius-md:12px;--radius-lg:20px;--radius-full:50%}
html{-webkit-text-size-adjust:100%;text-size-adjust:100%;touch-action:manipulation;font-size:16px}
html,body{height:100%;width:100%;font-family:'Segoe UI',system-ui,-apple-system,sans-serif;background:var(--bg-chat);overflow:hidden;-webkit-tap-highlight-color:transparent;position:fixed;top:0;left:0;right:0;bottom:0}
@keyframes fadeIn{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
@keyframes fadeInScale{from{opacity:0;transform:scale(0.95)}to{opacity:1;transform:scale(1)}}
@keyframes slideUp{from{transform:translateY(100%)}to{transform:translateY(0)}}
@keyframes slideDown{from{transform:translateY(-20px);opacity:0}to{transform:translateY(0);opacity:1}}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.4}}
@keyframes bounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-5px)}}
@keyframes recordPulse{0%{transform:scale(1);box-shadow:0 0 0 0 rgba(234,0,56,0.4)}50%{transform:scale(1.1);box-shadow:0 0 0 10px rgba(234,0,56,0)}100%{transform:scale(1);box-shadow:0 0 0 0 rgba(234,0,56,0)}}
@keyframes wave{0%,100%{height:4px}50%{height:18px}}
@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
@keyframes shimmer{0%{background-position:-200% 0}100%{background-position:200% 0}}
@keyframes ripple{0%{transform:scale(0);opacity:0.5}100%{transform:scale(2.5);opacity:0}}

.auth-screen{position:fixed;inset:0;background:linear-gradient(135deg,var(--wa-dark) 0%,var(--wa-teal) 50%,var(--wa-green) 100%);display:flex;align-items:center;justify-content:center;z-index:1000;padding:12px;overflow-y:auto}
.auth-screen::before{content:'';position:absolute;inset:0;background:url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='60' height='60'><circle cx='30' cy='30' r='1.5' fill='rgba(255,255,255,0.08)'/></svg>");background-size:30px 30px}
.auth-box{background:rgba(255,255,255,0.98);border-radius:var(--radius-lg);padding:24px 16px;width:100%;max-width:100%;box-shadow:var(--shadow-lg),0 0 0 1px rgba(255,255,255,0.1);animation:fadeInScale 0.5s ease;position:relative;backdrop-filter:blur(20px)}
.auth-logo{text-align:center;margin-bottom:20px}
.auth-logo h1{color:var(--wa-teal);font-size:clamp(1.5rem,5vw,2.2rem);font-weight:800;letter-spacing:-0.5px;text-shadow:0 2px 4px rgba(18,140,126,0.15)}
.auth-logo p{color:var(--text-secondary);font-size:clamp(0.8rem,2.5vw,0.95rem);margin-top:6px;font-weight:400}
.auth-tabs{display:flex;margin-bottom:16px;border-bottom:2px solid var(--border-light);gap:4px}
.auth-tab{flex:1;padding:12px 8px;text-align:center;cursor:pointer;color:var(--text-muted);font-size:clamp(0.85rem,3vw,1rem);font-weight:600;border-bottom:3px solid transparent;transition:all 0.3s ease;border-radius:var(--radius-sm) var(--radius-sm) 0 0}
.auth-tab:hover{color:var(--wa-teal);background:rgba(18,140,126,0.04)}
.auth-tab.active{color:var(--wa-teal);border-bottom-color:var(--wa-teal);background:rgba(18,140,126,0.06)}
.auth-form{display:none}
.auth-form.active{display:block;animation:fadeIn 0.35s ease}
.form-group{margin-bottom:14px}
.form-group label{display:block;font-size:clamp(0.7rem,2vw,0.8rem);color:var(--text-secondary);margin-bottom:4px;font-weight:600;text-transform:uppercase;letter-spacing:0.3px}
.form-group input,.form-group textarea,.form-group select{width:100%;padding:12px 14px;border:2px solid var(--border-light);border-radius:var(--radius-md);font-size:clamp(0.9rem,3vw,1rem);outline:none;transition:all 0.25s ease;font-family:inherit;background:var(--bg-white)}
.form-group input:focus,.form-group textarea:focus,.form-group select:focus{border-color:var(--wa-teal);box-shadow:0 0 0 3px rgba(18,140,126,0.1)}
.form-group input:hover,.form-group textarea:hover{border-color:#c5d4d2}
.form-group textarea{resize:vertical;min-height:60px}
.avatar-preview{width:80px;height:80px;border-radius:var(--radius-full);object-fit:cover;border:3px solid var(--wa-teal);display:block;margin:0 auto 8px;background:linear-gradient(135deg,#f0f0f0,#e0e0e0);box-shadow:var(--shadow-sm)}
.btn{width:100%;padding:14px;border:none;border-radius:var(--radius-md);font-size:clamp(1rem,3.5vw,1.2rem);font-weight:700;cursor:pointer;transition:all 0.25s ease;font-family:inherit;letter-spacing:0.3px}
.btn-primary{background:linear-gradient(135deg,var(--wa-teal),var(--wa-green));color:#fff;box-shadow:0 4px 15px rgba(18,140,126,0.35)}
.btn-primary:hover{transform:translateY(-2px);box-shadow:0 6px 20px rgba(18,140,126,0.45)}
.btn-primary:active{transform:translateY(0)}
.btn-secondary{background:transparent;color:var(--wa-teal);border:2px solid var(--wa-teal);margin-top:8px}
.btn-secondary:hover{background:rgba(18,140,126,0.06);transform:translateY(-1px)}
.btn-danger{background:linear-gradient(135deg,#ff416c,var(--danger));color:#fff;box-shadow:0 4px 15px rgba(234,0,56,0.3)}
.btn-danger:hover{transform:translateY(-2px);box-shadow:0 6px 20px rgba(234,0,56,0.4)}
.btn-gold{background:linear-gradient(135deg,var(--admin-gold),#FFA500);color:#333;box-shadow:0 4px 15px rgba(255,215,0,0.3)}
.btn-purple{background:linear-gradient(135deg,var(--vice-purple),#8E44AD);color:#fff;box-shadow:0 4px 15px rgba(155,89,182,0.3)}
.btn-sm{padding:6px 10px;font-size:clamp(0.75rem,2.5vw,0.85rem);width:auto;display:inline-block;border-radius:var(--radius-sm)}
.error-msg{color:var(--danger);font-size:clamp(0.8rem,2.5vw,0.9rem);text-align:center;margin-bottom:10px;display:none;font-weight:500;padding:8px;background:rgba(234,0,56,0.08);border-radius:var(--radius-sm)}
.success-msg{color:var(--wa-teal);font-size:clamp(0.8rem,2.5vw,0.9rem);text-align:center;margin-bottom:10px;display:none;font-weight:500;padding:8px;background:rgba(18,140,126,0.08);border-radius:var(--radius-sm)}
.forgot-link{text-align:center;font-size:clamp(0.8rem,2.5vw,0.9rem);color:var(--wa-teal);cursor:pointer;margin-top:12px;font-weight:500;transition:all 0.2s}
.forgot-link:hover{color:var(--wa-dark);text-decoration:underline}

.app{display:none;width:100%;height:100%;flex-direction:column;position:fixed;top:0;left:0;right:0;bottom:0;overflow:hidden}
.app.active{display:flex}
.chat-locked-banner{background:linear-gradient(90deg,var(--danger),#ff416c);color:#fff;text-align:center;padding:8px 12px;font-size:clamp(0.75rem,2.5vw,0.9rem);font-weight:700;letter-spacing:0.5px;display:none;animation:slideDown 0.3s ease;box-shadow:0 2px 8px rgba(234,0,56,0.3)}
.chat-locked-banner.active{display:block}

.chat-header{background:linear-gradient(135deg,var(--wa-dark),var(--wa-teal));color:#fff;padding:8px 12px;display:flex;align-items:center;gap:8px;box-shadow:var(--shadow-md);z-index:10;flex-shrink:0;height:56px;min-height:56px}
.chat-header-avatar{width:40px;height:40px;border-radius:var(--radius-full);object-fit:cover;border:2px solid rgba(255,255,255,0.25);cursor:pointer;background:#fff;transition:all 0.3s ease;box-shadow:0 2px 8px rgba(0,0,0,0.15)}
.chat-header-avatar:hover{transform:scale(1.08);border-color:rgba(255,255,255,0.5)}
.chat-header-info{flex:1;min-width:0}
.chat-header-info h2{font-size:clamp(0.9rem,3.5vw,1.1rem);font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;letter-spacing:-0.2px}
.chat-header-info span{font-size:clamp(0.7rem,2.5vw,0.8rem);color:rgba(255,255,255,0.75);font-weight:500}
.header-actions{display:flex;gap:6px}
.header-btn{width:40px;height:40px;border-radius:var(--radius-full);border:none;background:rgba(255,255,255,0.12);color:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all 0.25s ease;backdrop-filter:blur(4px);flex-shrink:0}
.header-btn:hover{background:rgba(255,255,255,0.25);transform:scale(1.08)}
.header-btn svg{width:22px;height:22px}

.chat-area{flex:1;overflow-y:auto;overflow-x:hidden;padding:10px 8px;background:linear-gradient(rgba(229,221,213,0.92),rgba(229,221,213,0.92)),url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='100' height='100'><rect fill='%23d5d5d5' width='100' height='100'/><circle fill='%23c5c5c5' cx='25' cy='25' r='1.5'/><circle fill='%23c5c5c5' cx='75' cy='75' r='1.5'/><circle fill='%23c5c5c5' cx='25' cy='75' r='1.5'/><circle fill='%23c5c5c5' cx='75' cy='25' r='1.5'/></svg>");background-size:cover,400px;scroll-behavior:smooth;-webkit-overflow-scrolling:touch}
.chat-area::-webkit-scrollbar{width:4px}
.chat-area::-webkit-scrollbar-track{background:transparent}
.chat-area::-webkit-scrollbar-thumb{background:rgba(0,0,0,0.18);border-radius:3px}

.date-separator{display:flex;align-items:center;justify-content:center;margin:14px 0 8px}
.date-separator span{background:linear-gradient(135deg,#E1F2FB,#d4edfc);color:var(--wa-teal);font-size:clamp(0.7rem,2.5vw,0.85rem);font-weight:700;padding:6px 16px;border-radius:14px;box-shadow:var(--shadow-sm);text-transform:capitalize;letter-spacing:0.3px}

.message-wrapper{display:flex;margin-bottom:4px;animation:fadeIn 0.35s ease;position:relative}
.message-wrapper.own{justify-content:flex-end}
.message{max-width:85%;padding:8px 10px 6px 10px;border-radius:var(--radius-md);box-shadow:var(--shadow-sm);position:relative;word-wrap:break-word;font-size:clamp(0.85rem,3vw,0.95rem);line-height:1.4;color:var(--text-primary);transition:transform 0.2s ease}
.message:hover{transform:scale(1.005)}
.message-wrapper.own .message{background:linear-gradient(135deg,var(--msg-me),#d4f5bc);border-bottom-right-radius:4px}
.message-wrapper.other .message{background:linear-gradient(135deg,var(--msg-other),#f8f9fa);border-bottom-left-radius:4px}
.message-wrapper.own .message::after{content:'';position:absolute;bottom:0;right:-6px;width:10px;height:14px;background:linear-gradient(135deg,var(--msg-me),#d4f5bc);clip-path:polygon(0 0,0% 100%,100% 0);border-bottom-right-radius:2px}
.message-wrapper.other .message::after{content:'';position:absolute;bottom:0;left:-6px;width:10px;height:14px;background:linear-gradient(135deg,var(--msg-other),#f8f9fa);clip-path:polygon(100% 0,0% 0,100% 100%);border-bottom-left-radius:2px}
.msg-avatar{width:36px;height:36px;border-radius:var(--radius-full);object-fit:cover;margin-right:6px;align-self:flex-end;cursor:pointer;border:2px solid rgba(255,255,255,0.6);background:#fff;box-shadow:var(--shadow-sm);transition:all 0.3s ease}
.msg-avatar:hover{transform:scale(1.15)}
.msg-sender{font-size:clamp(0.8rem,3vw,0.9rem);font-weight:700;color:var(--wa-teal);margin-bottom:2px;cursor:pointer;display:inline-flex;align-items:center;gap:4px}
.msg-sender:hover{text-decoration:underline}
.msg-content{margin-bottom:2px}
.msg-content a.chat-link{color:#027EB5;text-decoration:none;font-weight:500;border-bottom:1px dotted #027EB5}
.msg-content a.chat-link:hover{color:var(--wa-teal);border-bottom-style:solid}
.msg-reply{background:rgba(18,140,126,0.08);border-left:3px solid var(--wa-teal);padding:6px 10px;border-radius:var(--radius-sm);margin-bottom:4px;font-size:clamp(0.7rem,2.5vw,0.8rem);cursor:pointer;transition:all 0.2s ease}
.msg-reply:hover{background:rgba(18,140,126,0.14)}
.msg-reply-name{font-weight:700;color:var(--wa-teal);font-size:clamp(0.7rem,2.5vw,0.8rem)}
.msg-reply-text{color:var(--text-secondary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.msg-image{max-width:100%;border-radius:var(--radius-sm);cursor:pointer;display:block;margin-bottom:4px;box-shadow:var(--shadow-sm);transition:all 0.3s ease}
.msg-image:hover{transform:scale(1.02)}
.msg-audio{display:flex;align-items:center;gap:8px;padding:6px 0}
.msg-audio audio{max-width:200px;height:36px;border-radius:var(--radius-sm)}
.audio-icon{color:var(--wa-teal);font-size:18px}
.msg-file{display:flex;align-items:center;gap:8px;background:linear-gradient(135deg,rgba(0,0,0,0.03),rgba(0,0,0,0.06));padding:10px 12px;border-radius:var(--radius-sm);margin-bottom:4px;cursor:pointer;text-decoration:none;color:inherit;transition:all 0.2s ease;border:1px solid rgba(0,0,0,0.05)}
.msg-file:hover{background:linear-gradient(135deg,rgba(0,0,0,0.06),rgba(0,0,0,0.1));transform:translateX(3px)}
.file-icon{font-size:28px}
.file-info{flex:1;min-width:0}
.file-name{font-size:clamp(0.8rem,3vw,0.9rem);font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.file-size{font-size:clamp(0.65rem,2vw,0.75rem);color:var(--text-secondary);font-weight:500}
.msg-footer{display:flex;align-items:center;justify-content:flex-end;gap:4px;margin-top:2px}
.msg-time{font-size:clamp(0.6rem,2vw,0.7rem);color:var(--text-secondary);white-space:nowrap;font-weight:500}
.msg-status{display:flex;align-items:center;color:var(--text-muted);cursor:pointer;transition:all 0.2s ease}
.msg-status svg{width:14px;height:14px}
.msg-status.viewed{color:var(--info)}
.msg-status.sending{animation:pulse 1.2s infinite}
.msg-deleted{font-style:italic;color:var(--text-muted);font-size:clamp(0.7rem,2.5vw,0.8rem);padding:2px 0}
.role-badge{display:inline-flex;align-items:center;font-size:clamp(0.6rem,2vw,0.7rem);padding:2px 6px;border-radius:4px;font-weight:800;text-transform:uppercase;letter-spacing:0.5px;box-shadow:0 1px 3px rgba(0,0,0,0.15)}
.role-badge.admin{background:linear-gradient(135deg,var(--admin-gold),#FFA500);color:#333}
.role-badge.vice_admin{background:linear-gradient(135deg,var(--vice-purple),#8E44AD);color:#fff}

.context-menu{position:absolute;background:rgba(255,255,255,0.98);border-radius:var(--radius-md);box-shadow:var(--shadow-lg);z-index:100;min-width:180px;overflow:hidden;display:none;animation:fadeInScale 0.15s ease;border:1px solid var(--border-light);backdrop-filter:blur(10px)}
.context-menu-item{padding:12px 16px;font-size:clamp(0.85rem,3vw,0.95rem);cursor:pointer;display:flex;align-items:center;gap:10px;transition:all 0.15s ease;font-weight:500;color:var(--text-primary)}
.context-menu-item:hover{background:linear-gradient(90deg,rgba(18,140,126,0.08),rgba(18,140,126,0.04));color:var(--wa-teal)}
.context-menu-item.danger{color:var(--danger)}
.context-menu-item.danger:hover{background:linear-gradient(90deg,rgba(234,0,56,0.08),rgba(234,0,56,0.04));color:var(--danger)}
.context-menu-divider{height:1px;background:linear-gradient(90deg,transparent,var(--border-light),transparent);margin:4px 0}

.typing-indicator{display:none;align-items:center;padding:6px 10px;margin-bottom:6px}
.typing-indicator.active{display:flex}
.typing-bubble{background:linear-gradient(135deg,var(--msg-other),#f8f9fa);padding:10px 14px;border-radius:var(--radius-md);border-bottom-left-radius:4px;display:flex;gap:5px;box-shadow:var(--shadow-sm)}
.typing-dot{width:7px;height:7px;background:linear-gradient(135deg,var(--text-secondary),var(--text-muted));border-radius:var(--radius-full);animation:bounce 1.4s infinite ease-in-out}
.typing-dot:nth-child(1){animation-delay:0s}
.typing-dot:nth-child(2){animation-delay:0.2s}
.typing-dot:nth-child(3){animation-delay:0.4s}

.input-area{background:linear-gradient(180deg,var(--bg-input),#e8eaed);padding:8px 10px;display:flex;align-items:flex-end;gap:6px;border-top:1px solid var(--border-light);flex-shrink:0;min-height:56px;position:relative;z-index:5}
.input-btn{width:44px;height:44px;border-radius:var(--radius-full);border:none;background:rgba(255,255,255,0.7);color:var(--text-secondary);cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all 0.3s cubic-bezier(0.25,0.46,0.45,0.94);padding:0;position:relative;overflow:hidden;box-shadow:var(--shadow-sm);backdrop-filter:blur(4px)}
.input-btn::after{content:'';position:absolute;inset:0;border-radius:var(--radius-full);background:currentColor;opacity:0;transition:opacity 0.3s}
.input-btn:hover::after{opacity:0.1}
.input-btn:hover{color:var(--text-primary);background:rgba(255,255,255,0.95);transform:scale(1.08);box-shadow:var(--shadow-md)}
.input-btn:active{transform:scale(0.92)}
.input-btn svg{width:22px;height:22px;display:block}
.input-btn.send-btn{background:linear-gradient(135deg,var(--wa-teal),var(--wa-green));color:#fff;box-shadow:0 2px 8px rgba(18,140,126,0.4)}
.input-btn.send-btn:hover{background:linear-gradient(135deg,var(--wa-dark),var(--wa-teal));box-shadow:0 3px 12px rgba(18,140,126,0.5);transform:scale(1.1) translateY(-2px)}
.input-btn.send-btn:active{transform:scale(0.9)}
.input-btn.send-btn svg{width:20px;height:20px}
.input-btn.recording{background:linear-gradient(135deg,var(--danger),#ff416c);color:#fff;box-shadow:0 2px 8px rgba(234,0,56,0.4);animation:recordPulse 1.5s infinite}
.input-btn.recording:hover{background:linear-gradient(135deg,#c70030,var(--danger))}
.input-wrapper{flex:1;background:linear-gradient(180deg,#fff,#fafbfc);border-radius:20px;padding:10px 14px;display:flex;align-items:center;gap:8px;min-height:44px;max-height:120px;overflow:hidden;box-shadow:inset 0 1px 3px rgba(0,0,0,0.06),0 1px 2px rgba(0,0,0,0.04);border:1px solid rgba(0,0,0,0.04);transition:all 0.3s ease}
.input-wrapper:focus-within{box-shadow:inset 0 1px 3px rgba(0,0,0,0.06),0 0 0 3px rgba(18,140,126,0.1);border-color:rgba(18,140,126,0.2)}
.input-wrapper textarea{flex:1;border:none;outline:none;font-size:clamp(0.9rem,3vw,1rem);font-family:inherit;resize:none;min-height:20px;max-height:80px;background:transparent;line-height:1.4;width:100%;display:block;padding:0;margin:0;color:var(--text-primary)}
.input-wrapper textarea::placeholder{color:var(--text-muted);font-weight:400}
.char-count{font-size:clamp(0.6rem,2vw,0.7rem);color:var(--text-muted);white-space:nowrap;flex-shrink:0;font-weight:600;background:rgba(0,0,0,0.04);padding:1px 5px;border-radius:8px}

.recording-overlay{display:none;position:fixed;bottom:70px;left:50%;transform:translateX(-50%);background:linear-gradient(135deg,#fff,#f8f9fa);padding:14px 28px;border-radius:24px;box-shadow:var(--shadow-lg);z-index:100;align-items:center;gap:12px;border:1px solid var(--border-light);backdrop-filter:blur(10px)}
.recording-overlay.active{display:flex;animation:fadeInScale 0.3s ease}
.recording-dot{width:14px;height:14px;background:linear-gradient(135deg,var(--danger),#ff416c);border-radius:var(--radius-full);animation:pulse 1s infinite;box-shadow:0 0 8px rgba(234,0,56,0.4)}
.recording-time{font-size:clamp(0.9rem,3vw,1.1rem);font-weight:700;color:var(--text-primary);font-variant-numeric:tabular-nums;letter-spacing:1px}
.recording-wave{display:flex;align-items:center;gap:2px;height:16px}
.recording-wave span{width:3px;background:linear-gradient(180deg,var(--danger),#ff416c);border-radius:2px;animation:wave 0.6s infinite ease-in-out}
.recording-wave span:nth-child(1){animation-delay:0s;height:8px}
.recording-wave span:nth-child(2){animation-delay:0.1s;height:12px}
.recording-wave span:nth-child(3){animation-delay:0.2s;height:10px}
.recording-wave span:nth-child(4){animation-delay:0.15s;height:14px}
.recording-wave span:nth-child(5){animation-delay:0.05s;height:6px}

.camera-overlay{display:none;position:fixed;inset:0;background:#000;z-index:2000;flex-direction:column}
.camera-overlay.active{display:flex}
.camera-preview{flex:1;display:flex;align-items:center;justify-content:center;position:relative;overflow:hidden}
.camera-preview video{width:100%;height:100%;object-fit:cover}
.camera-preview canvas{display:none}
.camera-controls{display:flex;align-items:center;justify-content:center;gap:30px;padding:20px 16px;background:linear-gradient(180deg,rgba(0,0,0,0.7),rgba(0,0,0,0.9));backdrop-filter:blur(12px)}
.camera-btn{width:56px;height:56px;border-radius:var(--radius-full);border:2px solid rgba(255,255,255,0.35);background:rgba(255,255,255,0.1);cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all 0.3s ease;color:#fff;backdrop-filter:blur(4px)}
.camera-btn:hover{background:rgba(255,255,255,0.25);border-color:rgba(255,255,255,0.7);transform:scale(1.1)}
.camera-btn:active{transform:scale(0.9)}
.camera-btn svg{width:24px;height:24px}
.camera-btn.shutter{background:linear-gradient(135deg,#fff,#f0f0f0);width:64px;height:64px;border:3px solid rgba(255,255,255,0.35);box-shadow:0 0 0 2px rgba(255,255,255,0.15),0 4px 20px rgba(0,0,0,0.3)}
.camera-btn.shutter:hover{background:linear-gradient(135deg,#f5f5f5,#e8e8e8);transform:scale(1.08)}
.camera-btn.shutter::after{content:'';width:58px;height:58px;border-radius:var(--radius-full);background:linear-gradient(135deg,#fff,#f0f0f0);border:2px solid #444}
.camera-btn.cancel{border-color:var(--danger);color:var(--danger)}
.camera-btn.cancel:hover{background:rgba(234,0,56,0.2);border-color:#ff416c}

.reply-preview{display:none;background:linear-gradient(90deg,var(--bg-input),#e8eaed);padding:8px 12px;border-left:3px solid var(--wa-teal);align-items:center;gap:8px;animation:slideDown 0.2s ease}
.reply-preview.active{display:flex}
.reply-preview-text{flex:1;font-size:clamp(0.75rem,2.5vw,0.85rem);color:var(--text-secondary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:500}
.reply-preview-close{cursor:pointer;color:var(--text-muted);font-size:18px;width:28px;height:28px;display:flex;align-items:center;justify-content:center;border-radius:var(--radius-full);transition:all 0.2s ease}
.reply-preview-close:hover{background:rgba(0,0,0,0.06);color:var(--danger);transform:rotate(90deg)}

.file-preview{display:none;background:linear-gradient(90deg,var(--bg-input),#e8eaed);padding:8px 12px;align-items:center;gap:8px;animation:slideDown 0.2s ease}
.file-preview.active{display:flex}
.file-preview-name{flex:1;font-size:clamp(0.75rem,2.5vw,0.85rem);color:var(--text-secondary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:500}
.file-preview-close{cursor:pointer;color:var(--text-muted);font-size:18px;width:28px;height:28px;display:flex;align-items:center;justify-content:center;border-radius:var(--radius-full);transition:all 0.2s ease}
.file-preview-close:hover{background:rgba(0,0,0,0.06);color:var(--danger);transform:rotate(90deg)}

.image-viewer{position:fixed;inset:0;background:rgba(0,0,0,0.93);z-index:2000;display:none;align-items:center;justify-content:center;padding:12px;backdrop-filter:blur(8px)}
.image-viewer.active{display:flex;animation:fadeIn 0.3s ease}
.image-viewer img{max-width:100%;max-height:90vh;border-radius:var(--radius-md);box-shadow:var(--shadow-lg);animation:fadeInScale 0.3s ease}
.image-viewer-close{position:absolute;top:12px;right:12px;color:#fff;font-size:28px;cursor:pointer;width:48px;height:48px;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,0.1);border-radius:var(--radius-full);transition:all 0.3s ease;backdrop-filter:blur(4px);border:1px solid rgba(255,255,255,0.1)}
.image-viewer-close:hover{background:rgba(255,255,255,0.2);transform:rotate(90deg) scale(1.1)}

.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.65);z-index:1500;display:none;align-items:center;justify-content:center;padding:12px;backdrop-filter:blur(4px)}
.modal-overlay.active{display:flex;animation:fadeIn 0.25s ease}
.modal-box{background:linear-gradient(180deg,#fff,#fafbfc);border-radius:var(--radius-lg);width:100%;max-width:100%;max-height:90vh;overflow-y:auto;animation:fadeInScale 0.35s cubic-bezier(0.34,1.56,0.64,1);box-shadow:var(--shadow-lg);border:1px solid var(--border-light)}
.modal-header{background:linear-gradient(135deg,var(--wa-teal),var(--wa-green));color:#fff;padding:24px 20px;text-align:center;position:relative;border-radius:var(--radius-lg) var(--radius-lg) 0 0}
.modal-avatar{width:80px;height:80px;border-radius:var(--radius-full);object-fit:cover;border:3px solid rgba(255,255,255,0.3);background:#fff;box-shadow:var(--shadow-md)}
.modal-header h3{margin-top:8px;font-size:clamp(1.2rem,4vw,1.5rem);font-weight:700;letter-spacing:-0.3px}
.modal-body{padding:20px 16px}
.modal-field{margin-bottom:14px}
.modal-field label{font-size:clamp(0.65rem,2vw,0.75rem);color:var(--wa-teal);font-weight:700;text-transform:uppercase;letter-spacing:0.8px}
.modal-field p{font-size:clamp(0.9rem,3vw,1.1rem);color:var(--text-primary);margin-top:4px;font-weight:500}
.modal-close{position:absolute;top:8px;right:8px;color:#fff;font-size:24px;cursor:pointer;width:40px;height:40px;display:flex;align-items:center;justify-content:center;border-radius:var(--radius-full);transition:all 0.25s ease;background:rgba(255,255,255,0.1)}
.modal-close:hover{background:rgba(255,255,255,0.25);transform:rotate(90deg)}

.views-modal .modal-body{padding:0}
.views-list{max-height:280px;overflow-y:auto}
.view-item{display:flex;align-items:center;gap:10px;padding:14px 16px;border-bottom:1px solid var(--border-light);transition:all 0.15s ease}
.view-item:hover{background:rgba(18,140,126,0.03)}
.view-item img{width:40px;height:40px;border-radius:var(--radius-full);object-fit:cover}
.view-item-info{flex:1}
.view-item-name{font-size:clamp(0.85rem,3vw,0.95rem);font-weight:600}
.view-item-time{font-size:clamp(0.7rem,2.5vw,0.8rem);color:var(--text-secondary);font-weight:500}
.edit-profile-form{padding:20px 16px}

.toast{position:fixed;bottom:80px;left:50%;transform:translateX(-50%) translateY(120px);background:linear-gradient(135deg,#2d3436,#1a1e1f);color:#fff;padding:12px 24px;border-radius:24px;font-size:clamp(0.85rem,3vw,0.95rem);z-index:3000;opacity:0;transition:all 0.4s cubic-bezier(0.34,1.56,0.64,1);pointer-events:none;white-space:nowrap;box-shadow:var(--shadow-lg);font-weight:600;letter-spacing:0.3px}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0)}

.scroll-bottom{position:fixed;bottom:80px;right:12px;width:48px;height:48px;border-radius:var(--radius-full);background:linear-gradient(135deg,#fff,#f8f9fa);border:none;box-shadow:var(--shadow-md);cursor:pointer;display:none;align-items:center;justify-content:center;z-index:50;color:var(--text-secondary);transition:all 0.3s ease}
.scroll-bottom.show{display:flex;animation:fadeInScale 0.3s ease}
.scroll-bottom:hover{background:linear-gradient(135deg,var(--wa-teal),var(--wa-green));color:#fff;transform:translateY(-3px) scale(1.08);box-shadow:0 6px 20px rgba(18,140,126,0.4)}
.scroll-bottom .badge{position:absolute;top:-3px;right:-3px;background:linear-gradient(135deg,var(--danger),#ff416c);color:#fff;font-size:11px;min-width:22px;height:22px;border-radius:11px;display:flex;align-items:center;justify-content:center;font-weight:700;box-shadow:0 2px 6px rgba(234,0,56,0.4)}

.side-menu-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.55);z-index:1100;display:none;backdrop-filter:blur(3px)}
.side-menu-overlay.active{display:block;animation:fadeIn 0.3s ease}
.side-menu{position:fixed;top:0;left:0;width:280px;height:100%;background:linear-gradient(180deg,#fff,#f8f9fa);z-index:1200;transform:translateX(-100%);transition:transform 0.35s cubic-bezier(0.34,1.56,0.64,1);box-shadow:4px 0 20px rgba(0,0,0,0.12);display:flex;flex-direction:column;border-radius:0 var(--radius-lg) var(--radius-lg) 0}
.side-menu.open{transform:translateX(0)}
.side-menu-header{background:linear-gradient(135deg,var(--wa-dark),var(--wa-teal));color:#fff;padding:30px 16px 16px;position:relative;border-radius:0 var(--radius-lg) 0 0}
.side-menu-avatar{width:60px;height:60px;border-radius:var(--radius-full);object-fit:cover;border:2px solid rgba(255,255,255,0.3);cursor:pointer;background:#fff;box-shadow:var(--shadow-md);transition:all 0.3s ease}
.side-menu-avatar:hover{transform:scale(1.08)}
.side-menu-header h3{margin-top:8px;font-size:clamp(1.1rem,4vw,1.3rem);font-weight:700}
.side-menu-header p{font-size:clamp(0.75rem,2.5vw,0.85rem);opacity:0.85;font-weight:500}
.side-menu-items{flex:1;overflow-y:auto;padding:8px 0}
.side-menu-item{display:flex;align-items:center;gap:14px;padding:14px 18px;cursor:pointer;transition:all 0.2s ease;color:var(--text-primary);text-decoration:none;font-weight:500;font-size:clamp(0.85rem,3vw,0.95rem);margin:2px 6px;border-radius:var(--radius-md)}
.side-menu-item:hover{background:linear-gradient(90deg,rgba(18,140,126,0.08),rgba(18,140,126,0.03));color:var(--wa-teal);transform:translateX(4px)}
.side-menu-item svg{width:22px;height:22px;color:var(--text-muted);transition:all 0.2s ease;flex-shrink:0}
.side-menu-item:hover svg{color:var(--wa-teal)}

.all-users-list{max-height:350px;overflow-y:auto}
.all-user-item{display:flex;align-items:center;gap:10px;padding:14px 16px;border-bottom:1px solid var(--border-light);cursor:pointer;transition:all 0.2s ease}
.all-user-item:hover{background:linear-gradient(90deg,rgba(18,140,126,0.05),transparent);transform:translateX(3px)}
.all-user-item img{width:44px;height:44px;border-radius:var(--radius-full);object-fit:cover;flex-shrink:0;border:2px solid rgba(255,255,255,0.6);box-shadow:var(--shadow-sm)}
.all-user-info{flex:1;min-width:0}
.all-user-name{font-size:clamp(0.9rem,3vw,1rem);font-weight:600;color:var(--text-primary)}
.all-user-status{font-size:clamp(0.7rem,2.5vw,0.8rem);color:var(--text-secondary);margin-top:2px;font-weight:500}
.all-user-dot{width:14px;height:14px;border-radius:var(--radius-full);flex-shrink:0;box-shadow:0 0 4px currentColor}
.all-user-dot.online{background:linear-gradient(135deg,var(--online),#00D68F)}
.all-user-dot.offline{background:linear-gradient(135deg,var(--offline),#a0aec0)}

.admin-panel{max-height:65vh;overflow-y:auto;padding:4px}
.admin-stats{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin-bottom:14px}
.admin-stat{background:linear-gradient(135deg,#f8f9fa,#e9ecef);padding:16px 12px;border-radius:var(--radius-md);text-align:center;border:1px solid var(--border-light);transition:all 0.3s ease}
.admin-stat:hover{transform:translateY(-3px);box-shadow:var(--shadow-sm)}
.admin-stat-value{font-size:clamp(1.3rem,5vw,1.8rem);font-weight:800;background:linear-gradient(135deg,var(--wa-teal),var(--wa-green));-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
.admin-stat-label{font-size:clamp(0.6rem,2vw,0.7rem);color:var(--text-secondary);margin-top:4px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px}
.admin-user-item{display:flex;align-items:flex-start;gap:8px;padding:12px 10px;border-bottom:1px solid var(--border-light);transition:all 0.2s ease;flex-wrap:wrap}
.admin-user-item:hover{background:linear-gradient(90deg,rgba(18,140,126,0.04),transparent)}
.admin-user-item img{width:40px;height:40px;border-radius:var(--radius-full);object-fit:cover;border:2px solid rgba(255,255,255,0.6);box-shadow:var(--shadow-sm);flex-shrink:0}
.admin-user-info{flex:1;min-width:0}
.admin-user-name{font-size:clamp(0.85rem,3vw,0.95rem);font-weight:600}
.admin-user-meta{font-size:clamp(0.7rem,2.5vw,0.8rem);color:var(--text-secondary);font-weight:500}
.admin-user-actions{display:flex;gap:4px;flex-wrap:wrap;margin-top:6px;width:100%}
.admin-logs{max-height:280px;overflow-y:auto}
.admin-log-item{padding:12px 14px;border-bottom:1px solid var(--border-light);font-size:clamp(0.75rem,2.5vw,0.85rem);transition:all 0.15s ease}
.admin-log-item:hover{background:rgba(18,140,126,0.03)}
.admin-log-time{color:var(--text-secondary);font-size:clamp(0.65rem,2vw,0.75rem);font-weight:500}

@media(min-width:768px){
.auth-box{max-width:480px;padding:36px 32px}
.auth-logo h1{font-size:2rem}
.auth-tab{padding:14px;font-size:1rem}
.form-group input,.form-group textarea,.form-group select{padding:14px 18px}
.btn{padding:16px;font-size:1.1rem}
.avatar-preview{width:100px;height:100px}
.chat-header{padding:10px 16px;height:60px;min-height:60px}
.chat-header-avatar{width:44px;height:44px}
.chat-header-info h2{font-size:1.05rem}
.header-btn{width:44px;height:44px}
.header-btn svg{width:24px;height:24px}
.chat-area{padding:14px 12px}
.message{max-width:75%;padding:10px 12px 8px 12px;font-size:0.95rem}
.msg-avatar{width:40px;height:40px}
.msg-audio audio{max-width:240px;height:40px}
.input-area{padding:10px 14px;min-height:60px}
.input-btn{width:48px;height:48px}
.input-btn svg{width:24px;height:24px}
.input-wrapper{padding:12px 16px;min-height:48px}
.input-wrapper textarea{font-size:0.95rem;max-height:100px}
.side-menu{width:320px}
.side-menu-header{padding:36px 20px 18px}
.side-menu-avatar{width:72px;height:72px}
.side-menu-item{padding:16px 20px;font-size:0.95rem}
.side-menu-item svg{width:24px;height:24px}
.modal-box{max-width:520px}
.modal-header{padding:28px 24px}
.modal-avatar{width:100px;height:100px}
.modal-body{padding:24px 20px}
.edit-profile-form{padding:24px 20px}
.admin-panel{max-height:70vh}
.admin-stat{padding:20px 16px}
.admin-user-item{padding:14px 12px}
.admin-user-item img{width:48px;height:48px}
}

@media(min-width:1024px){
.auth-box{max-width:520px;padding:44px 36px}
.auth-logo h1{font-size:2.2rem}
.auth-logo p{font-size:0.95rem}
.auth-tab{padding:16px;font-size:1.05rem}
.form-group{margin-bottom:18px}
.form-group input,.form-group textarea,.form-group select{padding:16px 20px;font-size:1rem}
.btn{padding:18px;font-size:1.15rem}
.avatar-preview{width:120px;height:120px}
.chat-header{padding:12px 20px;height:64px;min-height:64px}
.chat-header-avatar{width:48px;height:48px}
.chat-header-info h2{font-size:1.1rem}
.header-btn{width:48px;height:48px}
.header-btn svg{width:26px;height:26px}
.chat-area{padding:16px 14px}
.message{max-width:70%;padding:12px 14px 8px 14px;font-size:1rem}
.msg-avatar{width:44px;height:44px;margin-right:8px}
.msg-audio audio{max-width:260px;height:40px}
.file-icon{font-size:32px}
.input-area{padding:12px 16px;min-height:64px;gap:8px}
.input-btn{width:52px;height:52px}
.input-btn svg{width:26px;height:26px}
.input-wrapper{padding:12px 18px;min-height:48px;border-radius:24px}
.input-wrapper textarea{font-size:1rem;max-height:100px}
.side-menu{width:340px}
.side-menu-header{padding:40px 20px 18px}
.side-menu-avatar{width:72px;height:72px}
.side-menu-item{padding:16px 22px;font-size:1rem}
.modal-box{max-width:560px}
.modal-header{padding:32px 28px}
.modal-avatar{width:110px;height:110px}
.modal-body{padding:28px 24px}
.edit-profile-form{padding:28px 24px}
.admin-panel{max-height:72vh}
.admin-stats{grid-template-columns:repeat(4,1fr)}
.admin-stat{padding:24px 16px}
.admin-stat-value{font-size:1.8rem}
.admin-user-item{padding:14px 12px}
.admin-user-item img{width:48px;height:48px}
}

@media(min-width:1440px){
.app.active{max-width:1200px;margin:0 auto}
.chat-area{padding:18px 20px}
.message{max-width:65%}
}

@media(prefers-color-scheme:dark){
body{background:var(--bg-dark)}
.chat-area{background:linear-gradient(rgba(15,20,25,0.95),rgba(15,20,25,0.95)),url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='100' height='100'><rect fill='%231a1f24' width='100' height='100'/><circle fill='%23252a30' cx='25' cy='25' r='1.5'/><circle fill='%23252a30' cx='75' cy='75' r='1.5'/></svg>");background-size:cover,400px}
.message-wrapper.own .message{background:linear-gradient(135deg,var(--msg-dark-me),#006d5a);color:var(--text-dark)}
.message-wrapper.other .message{background:linear-gradient(135deg,var(--msg-dark-other),#2a3540);color:var(--text-dark)}
.message-wrapper.own .message::after{background:linear-gradient(135deg,var(--msg-dark-me),#006d5a)}
.message-wrapper.other .message::after{background:linear-gradient(135deg,var(--msg-dark-other),#2a3540)}
.input-area{background:linear-gradient(180deg,#1a1f24,#15191d);border-color:var(--border-dark)}
.input-wrapper{background:linear-gradient(180deg,#2a3540,#252f38);border-color:var(--border-dark)}
.input-wrapper textarea{color:var(--text-dark)}
.input-wrapper textarea::placeholder{color:#5a6874}
.reply-preview{background:linear-gradient(90deg,#1a1f24,#15191d);border-color:var(--wa-teal)}
.file-preview{background:linear-gradient(90deg,#1a1f24,#15191d)}
.typing-bubble{background:linear-gradient(135deg,var(--msg-dark-other),#2a3540)}
.msg-reply{background:rgba(255,255,255,0.06)}
.msg-file{background:linear-gradient(135deg,rgba(255,255,255,0.05),rgba(255,255,255,0.08))}
.side-menu{background:linear-gradient(180deg,#111B21,#0f1419)}
.side-menu-item:hover{background:linear-gradient(90deg,rgba(18,140,126,0.1),transparent)}
.modal-box{background:linear-gradient(180deg,#111B21,#0f1419);border-color:var(--border-dark)}
.modal-field p{color:var(--text-dark)}
.context-menu{background:linear-gradient(180deg,#1f2c33,#1a2429);border-color:var(--border-dark)}
.context-menu-item:hover{background:linear-gradient(90deg,rgba(18,140,126,0.12),transparent)}
.context-menu-item{color:var(--text-dark)}
.auth-box{background:linear-gradient(180deg,#1f2c33,#1a2429)}
.form-group input,.form-group textarea,.form-group select{background:linear-gradient(180deg,#2a3540,#252f38);color:var(--text-dark);border-color:var(--border-dark)}
.form-group label{color:#6a7d8a}
.auth-logo h1{color:var(--wa-teal)}
.auth-tab{color:#6a7d8a}
.auth-tab.active{color:var(--wa-teal)}
.forgot-link{color:var(--info)}
.date-separator span{background:linear-gradient(135deg,#182229,#1f2c33);color:var(--info)}
.recording-overlay{background:linear-gradient(135deg,#1f2c33,#1a2429);border-color:var(--border-dark)}
.recording-time{color:var(--text-dark)}
.all-user-item:hover{background:linear-gradient(90deg,rgba(18,140,126,0.08),transparent)}
.all-user-name{color:var(--text-dark)}
.admin-stat{background:linear-gradient(135deg,#1f2c33,#1a2429);border-color:var(--border-dark)}
.admin-user-item{border-color:var(--border-dark)}
.admin-log-item{border-color:var(--border-dark)}
.admin-log-item:hover{background:rgba(18,140,126,0.06)}
.scroll-bottom{background:linear-gradient(135deg,#2a3540,#252f38);color:var(--text-dark)}
}
</style>
<body>



<!-- AUTH SCREEN -->
<div class="auth-screen" id="authScreen">
    <div class="auth-box">
        <div class="auth-logo">
            <h1>💬 WHATSAPP CHAT</h1>
            <p>Chat Universal - Converse com o mundo</p>
        </div>
        <div class="auth-tabs">
            <div class="auth-tab active" onclick="showTab('login', this)">Entrar</div>
            <div class="auth-tab" onclick="showTab('register', this)">Criar Conta</div>
        </div>
        <form class="auth-form active" id="loginForm" onsubmit="return doLogin(event)">
            <div class="error-msg" id="loginError"></div>
            <div class="form-group">
                <label>Usuário</label>
                <input type="text" name="username" placeholder="Seu usuário" required autocomplete="username">
            </div>
            <div class="form-group">
                <label>Senha</label>
                <input type="password" name="password" placeholder="Sua senha" required autocomplete="current-password">
            </div>
            <button type="submit" class="btn btn-primary">Entrar</button>
            <div class="forgot-link" onclick="showRecover()">Esqueceu a senha? Use seu PIN</div>
        </form>
        <form class="auth-form" id="registerForm" onsubmit="return doRegister(event)" enctype="multipart/form-data">
            <div class="error-msg" id="registerError"></div>
            <div class="success-msg" id="registerSuccess"></div>
            <div class="form-group">
                <img src="" class="avatar-preview" id="regAvatarPreview" style="display:none">
                <label>Foto de Perfil (opcional)</label>
                <input type="file" name="avatar" accept="image/*" onchange="previewAvatar(this, 'regAvatarPreview')">
            </div>
            <div class="form-group">
                <label>Usuário *</label>
                <input type="text" name="username" placeholder="3-20 caracteres" required minlength="3" maxlength="20" pattern="[a-zA-Z0-9_]+">
            </div>
            <div class="form-group">
                <label>Senha *</label>
                <input type="password" name="password" placeholder="Mínimo 6 caracteres" required minlength="6">
            </div>
            <div class="form-group">
                <label>PIN de Recuperação *</label>
                <input type="text" name="pin" placeholder="4-10 dígitos numéricos" required minlength="4" maxlength="10" pattern="\d+">
            </div>
            <div class="form-group">
                <label>Descrição</label>
                <textarea name="description" placeholder="Fale um pouco sobre você" maxlength="200"></textarea>
            </div>
            <div class="form-group">
                <label>País</label>
                <input type="text" name="country" placeholder="Ex: Brasil" maxlength="50">
            </div>
            <div class="form-group">
                <label>Idioma Nativo</label>
                <input type="text" name="language" placeholder="Ex: Português" maxlength="50">
            </div>
            <button type="submit" class="btn btn-primary">Criar Conta</button>
        </form>
        <form class="auth-form" id="recoverForm" onsubmit="return doRecover(event)">
            <div class="error-msg" id="recoverError"></div>
            <div class="success-msg" id="recoverSuccess"></div>
            <div class="form-group">
                <label>Usuário</label>
                <input type="text" name="username" placeholder="Seu usuário" required>
            </div>
            <div class="form-group">
                <label>PIN de Recuperação</label>
                <input type="text" name="pin" placeholder="Seu PIN" required pattern="\d+">
            </div>
            <div class="form-group">
                <label>Nova Senha</label>
                <input type="password" name="new_password" placeholder="Mínimo 6 caracteres" required minlength="6">
            </div>
            <button type="submit" class="btn btn-primary">Redefinir Senha</button>
            <button type="button" class="btn btn-secondary" onclick="showRecoverBack()">Voltar ao Login</button>
        </form>
    </div>
</div>

<!-- APP -->
<div class="app" id="app">
    <div class="chat-locked-banner" id="chatLockedBanner">🔒 CHAT FECHADO - Apenas admins podem enviar mensagens</div>
    <div class="chat-header">
        <img src="" class="chat-header-avatar" id="headerAvatar" onclick="showMyProfile()" alt="">
        <div class="chat-header-info">
            <h2>💬 WHATSAPP CHAT</h2>
            <span id="onlineCount">Carregando...</span>
        </div>
        <div class="header-actions">
            <button class="header-btn" onclick="toggleSideMenu()" title="Menu">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12h18M3 6h18M3 18h18"/></svg>
            </button>
        </div>
    </div>
    <div class="chat-area" id="chatArea">
        <div id="messagesContainer"></div>
        <div class="typing-indicator" id="typingIndicator">
            <div class="typing-bubble">
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
            </div>
        </div>
    </div>
    <div class="reply-preview" id="replyPreview">
        <div class="reply-preview-text" id="replyPreviewText"></div>
        <span class="reply-preview-close" onclick="cancelReply()">✕</span>
    </div>
    <div class="file-preview" id="filePreview">
        <span>📎</span>
        <span class="file-preview-name" id="filePreviewName"></span>
        <span class="file-preview-close" onclick="cancelFile()">✕</span>
    </div>
    <div class="input-area" id="inputArea">
        <input type="file" id="fileInput" style="display:none" onchange="onFileSelected(this)">
        <button class="input-btn" onclick="document.getElementById('fileInput').click()" title="Anexar arquivo">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.2 9.19a2 2 0 01-2.83-2.83l8.49-8.48"/></svg>
        </button>
        <button class="input-btn" onclick="openCamera()" title="Tirar foto">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z"/><circle cx="12" cy="13" r="4"/></svg>
        </button>
        <div class="input-wrapper">
            <textarea id="messageInput" placeholder="Mensagem" rows="1" maxlength="1000" onkeydown="handleKeyDown(event)" oninput="autoResize(this); updateCharCount(this)"></textarea>
            <span class="char-count" id="charCount">0/1000</span>
        </div>
        <button class="input-btn send-btn" id="sendBtn" onclick="sendMessage()" title="Enviar">
            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
        </button>
        <button class="input-btn" id="recordBtn" onclick="toggleRecording()" title="Toque para gravar áudio">
            <svg viewBox="0 0 24 24" fill="currentColor" id="recordIcon"><path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3z"/><path d="M17 11c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z"/></svg>
        </button>
    </div>
</div>

<!-- Recording Overlay -->
<div class="recording-overlay" id="recordingOverlay">
    <div class="recording-dot"></div>
    <div class="recording-wave">
        <span></span><span></span><span></span><span></span><span></span>
    </div>
    <div class="recording-time" id="recordingTime">00:00</div>
</div>

<!-- Camera Overlay -->
<div class="camera-overlay" id="cameraOverlay">
    <div class="camera-preview">
        <video id="cameraVideo" autoplay playsinline></video>
        <canvas id="cameraCanvas"></canvas>
    </div>
    <div class="camera-controls">
        <button class="camera-btn cancel" onclick="closeCamera()" title="Cancelar">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>
        <button class="camera-btn shutter" onclick="takePhoto()" title="Tirar foto"></button>
        <button class="camera-btn" id="flipCameraBtn" onclick="flipCamera()" title="Alternar câmera">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 4v6h-6M1 20v-6h6M20.49 9A9 9 0 005.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 013.51 15"/></svg>
        </button>
    </div>
</div>

<!-- Context Menu -->
<div class="context-menu" id="contextMenu">
    <div class="context-menu-item" onclick="replyToMessage()"><span>↩️</span> Responder</div>
    <div class="context-menu-item" onclick="copyMessage()"><span>📋</span> Copiar</div>
    <div class="context-menu-divider" id="adminContextDivider" style="display:none"></div>
    <div class="context-menu-item" id="adminDeleteMsgItem" style="display:none" onclick="adminDeleteMessage()"><span>🗑️</span> Apagar (Admin)</div>
    <div class="context-menu-divider"></div>
    <div class="context-menu-item" onclick="deleteForMe()"><span>🗑️</span> Excluir para mim</div>
    <div class="context-menu-item danger" id="deleteForAllItem" onclick="deleteForAll()"><span>🗑️</span> Excluir para todos</div>
</div>

<!-- Image Viewer -->
<div class="image-viewer" id="imageViewer" onclick="closeImageViewer()">
    <span class="image-viewer-close">✕</span>
    <img src="" id="imageViewerImg" alt="">
</div>

<!-- Profile Modal -->
<div class="modal-overlay" id="profileModal" onclick="closeModal(event, 'profileModal')">
    <div class="modal-box" onclick="event.stopPropagation()">
        <div class="modal-header">
            <span class="modal-close" onclick="hideModal('profileModal')">✕</span>
            <img src="" class="modal-avatar" id="profileAvatar" alt="">
            <h3 id="profileName">Usuário</h3>
        </div>
        <div class="modal-body" id="profileBody">
            <div class="modal-field"><label>Descrição</label><p id="profileDescription">-</p></div>
            <div class="modal-field"><label>País</label><p id="profileCountry">-</p></div>
            <div class="modal-field"><label>Idioma</label><p id="profileLanguage">-</p></div>
            <div class="modal-field"><label>Membro desde</label><p id="profileJoined">-</p></div>
        </div>
    </div>
</div>

<!-- Edit Profile Modal -->
<div class="modal-overlay" id="editProfileModal" onclick="closeModal(event, 'editProfileModal')">
    <div class="modal-box" onclick="event.stopPropagation()">
        <div class="modal-header">
            <span class="modal-close" onclick="hideModal('editProfileModal')">✕</span>
            <h3>Editar Perfil</h3>
        </div>
        <form class="edit-profile-form" onsubmit="return saveProfile(event)">
            <div class="form-group">
                <img src="" class="avatar-preview" id="editAvatarPreview" style="display:none">
                <label>Nova Foto</label>
                <input type="file" name="avatar" accept="image/*" onchange="previewAvatar(this, 'editAvatarPreview')">
            </div>
            <div class="form-group">
                <label>Descrição</label>
                <textarea name="description" id="editDescription" maxlength="200"></textarea>
            </div>
            <div class="form-group">
                <label>País</label>
                <input type="text" name="country" id="editCountry" maxlength="50">
            </div>
            <div class="form-group">
                <label>Idioma Nativo</label>
                <input type="text" name="language" id="editLanguage" maxlength="50">
            </div>
            <button type="submit" class="btn btn-primary">Salvar Alterações</button>
        </form>
    </div>
</div>

<!-- Views Modal -->
<div class="modal-overlay views-modal" id="viewsModal" onclick="closeModal(event, 'viewsModal')">
    <div class="modal-box" onclick="event.stopPropagation()">
        <div class="modal-header">
            <span class="modal-close" onclick="hideModal('viewsModal')">✕</span>
            <h3>Visualizações</h3>
        </div>
        <div class="views-list" id="viewsList"></div>
    </div>
</div>

<!-- All Users Modal -->
<div class="modal-overlay" id="allUsersModal" onclick="closeModal(event, 'allUsersModal')">
    <div class="modal-box" onclick="event.stopPropagation()">
        <div class="modal-header">
            <span class="modal-close" onclick="hideModal('allUsersModal')">✕</span>
            <h3>Todos os Usuários</h3>
        </div>
        <div class="all-users-list" id="allUsersList"></div>
    </div>
</div>

<!-- ===== ADMIN PANEL MODAL ===== -->
<div class="modal-overlay" id="adminPanelModal" onclick="closeModal(event, 'adminPanelModal')">
    <div class="modal-box" onclick="event.stopPropagation()" style="max-width: 640px;">
        <div class="modal-header" style="background: var(--admin-gold);">
            <span class="modal-close" onclick="hideModal('adminPanelModal')">✕</span>
            <h3>👑 Painel Admin Geral</h3>
        </div>
        <div class="modal-body admin-panel" id="adminPanelBody">
            <div class="admin-stats" id="adminStats"></div>
            <div style="display:flex; gap:8px; margin-bottom:12px; flex-wrap:wrap;">
                <button class="btn btn-sm btn-danger" onclick="adminToggleChat()" id="adminToggleChatBtn">🔒 Fechar Chat</button>
                <button class="btn btn-sm btn-secondary" onclick="adminLoadUsers()">🔄 Atualizar Usuários</button>
                <button class="btn btn-sm btn-secondary" onclick="adminLoadLogs()">📋 Ver Logs</button>
            </div>
            <div id="adminUsersList"></div>
            <div id="adminLogsList" style="display:none"></div>
        </div>
    </div>
</div>

<!-- ===== VICE ADMIN PANEL MODAL ===== -->
<div class="modal-overlay" id="viceAdminPanelModal" onclick="closeModal(event, 'viceAdminPanelModal')">
    <div class="modal-box" onclick="event.stopPropagation()" style="max-width: 640px;">
        <div class="modal-header" style="background: var(--vice-purple);">
            <span class="modal-close" onclick="hideModal('viceAdminPanelModal')">✕</span>
            <h3>🛡️ Painel Vice-Admin</h3>
        </div>
        <div class="modal-body admin-panel" id="viceAdminPanelBody">
            <div style="display:flex; gap:8px; margin-bottom:12px; flex-wrap:wrap;">
                <button class="btn btn-sm btn-secondary" onclick="viceAdminLoadUsers()">🔄 Atualizar Usuários</button>
            </div>
            <div id="viceAdminUsersList"></div>
        </div>
    </div>
</div>

<!-- ===== ADMIN EDIT USER MODAL ===== -->
<div class="modal-overlay" id="adminEditUserModal" onclick="closeModal(event, 'adminEditUserModal')">
    <div class="modal-box" onclick="event.stopPropagation()">
        <div class="modal-header">
            <span class="modal-close" onclick="hideModal('adminEditUserModal')">✕</span>
            <h3>Editar Usuário</h3>
        </div>
        <form class="edit-profile-form" onsubmit="return adminSaveUser(event)">
            <input type="hidden" id="editTargetUserId">
            <div class="form-group">
                <label>Usuário</label>
                <input type="text" id="editTargetUsername" disabled>
            </div>
            <div class="form-group">
                <label>Nova Senha (deixe em branco para não mudar)</label>
                <input type="password" name="password" minlength="6">
            </div>
            <div class="form-group">
                <label>Novo PIN (deixe em branco para não mudar)</label>
                <input type="text" name="pin" pattern="\d+" minlength="4" maxlength="10">
            </div>
            <div class="form-group">
                <label>Descrição</label>
                <textarea name="description" id="editTargetDescription" maxlength="200"></textarea>
            </div>
            <div class="form-group">
                <label>País</label>
                <input type="text" name="country" id="editTargetCountry" maxlength="50">
            </div>
            <div class="form-group">
                <label>Idioma</label>
                <input type="text" name="language" id="editTargetLanguage" maxlength="50">
            </div>
            <div class="form-group">
                <label>Cargo</label>
                <select name="role" id="editTargetRole">
                    <option value="user">Usuário</option>
                    <option value="vice_admin">Vice-Admin</option>
                    <option value="admin">Admin Geral</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Salvar Alterações</button>
        </form>
    </div>
</div>

<!-- Side Menu -->
<div class="side-menu-overlay" id="sideMenuOverlay" onclick="toggleSideMenu()"></div>
<div class="side-menu" id="sideMenu">
    <div class="side-menu-header">
        <img src="" class="side-menu-avatar" id="sideMenuAvatar" onclick="showMyProfile(); toggleSideMenu();" alt="">
        <h3 id="sideMenuName">Usuário</h3>
        <p id="sideMenuStatus">online</p>
    </div>
    <div class="side-menu-items">
        <div class="side-menu-item" onclick="showMyProfile(); toggleSideMenu();">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            <span>Meu Perfil</span>
        </div>
        <div class="side-menu-item" onclick="showEditProfile(); toggleSideMenu();">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            <span>Editar Perfil</span>
        </div>
        <div class="side-menu-item" onclick="showAllUsers(); toggleSideMenu();">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
            <span>Todos os Usuários</span>
        </div>
        <div class="side-menu-item" id="adminMenuItem" style="display:none" onclick="showAdminPanel(); toggleSideMenu();">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
            <span>Painel Admin</span>
        </div>
        <div class="side-menu-item" id="viceAdminMenuItem" style="display:none" onclick="showViceAdminPanel(); toggleSideMenu();">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
            <span>Painel Vice-Admin</span>
        </div>
        <div class="side-menu-item" onclick="doLogout(); toggleSideMenu();">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
            <span>Sair</span>
        </div>
    </div>
</div>

<!-- Scroll Bottom -->
<button class="scroll-bottom" id="scrollBottom" onclick="scrollToBottom()">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 9l-7 7-7-7"/></svg>
    <span class="badge" id="newMessagesBadge" style="display:none">0</span>
</button>

<!-- Toast -->
<div class="toast" id="toast"></div>

<script>
// ============================================================
// VARIAVEIS GLOBAIS
// ============================================================
let currentUser = null;
let currentRole = 'user';
let lastMessageId = 0;
let replyToId = null;
let selectedFile = null;
let contextMsgId = null;
let contextMsgUserId = null;
let contextMsgIsOwn = false;
let newMessagesCount = 0;
let isAtBottom = true;
let pollInterval = null;
let cachedAllUsers = [];
let lastDateSeparator = null;
let chatLocked = false;

// Gravacao
let mediaRecorder = null;
let recordedChunks = [];
let recordingStartTime = 0;
let recordingTimer = null;
let isRecording = false;

// Camera
let cameraStream = null;
let currentCameraFacing = 'environment';

// Admin cache
let adminUsersCache = [];

// ============================================================
// UTILITARIOS
// ============================================================
function $(id) { return document.getElementById(id); }

function showToast(msg) {
    const t = $('toast');
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 3000);
}

function formatTime(ts) {
    const d = new Date(ts * 1000);
    return d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function makeLinks(text) {
    return text.replace(/(https?:\/\/[^\s<]+)/gi, '<a href="$1" target="_blank" rel="noopener noreferrer" class="chat-link">$1</a>');
}

function getAvatarUrl(avatar) {
    return avatar ? '?action=avatar&f=' + encodeURIComponent(avatar) : '?action=avatar&f=default';
}

function getFileUrl(filePath) {
    return '?action=file&f=' + encodeURIComponent(filePath);
}

function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function formatDateSeparator(ts) {
    const d = new Date(ts * 1000);
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const msgDate = new Date(d.getFullYear(), d.getMonth(), d.getDate());

    if (msgDate.getTime() === today.getTime()) return 'Hoje';
    if (msgDate.getTime() === yesterday.getTime()) return 'Ontem';

    const days = ['Domingo','Segunda-feira','Terça-feira','Quarta-feira','Quinta-feira','Sexta-feira','Sábado'];
    const months = ['','Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];

    if (now.getTime() - d.getTime() < 7 * 86400000) return days[d.getDay()];
    return d.getDate() + ' de ' + months[d.getMonth() + 1] + ' de ' + d.getFullYear();
}

function formatLastSeen(ts) {
    const diff = Math.floor((Date.now() / 1000) - ts);
    if (diff < 60) return 'online agora';
    if (diff < 3600) return 'visto por último ha ' + Math.floor(diff/60) + ' min';
    if (diff < 7200) return 'visto por último ha 1 hora';
    if (diff < 86400) return 'visto por último ha ' + Math.floor(diff/3600) + ' horas';
    if (diff < 172800) return 'visto por último ontem as ' + new Date(ts * 1000).toLocaleTimeString('pt-BR', {hour:'2-digit', minute:'2-digit'});
    return 'visto por último ' + new Date(ts * 1000).toLocaleDateString('pt-BR') + ' as ' + new Date(ts * 1000).toLocaleTimeString('pt-BR', {hour:'2-digit', minute:'2-digit'});
}

function getRoleBadge(role) {
    if (role === 'admin') return '<span class="role-badge admin">Admin</span>';
    if (role === 'vice_admin') return '<span class="role-badge vice_admin">Vice</span>';
    return '';
}

// ============================================================
// AUTENTICACAO
// ============================================================
function showTab(tab, el) {
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
    if (el) el.classList.add('active');
    $(tab + 'Form').classList.add('active');
}

function showRecover() {
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
    $('recoverForm').classList.add('active');
}

function showRecoverBack() {
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
    $('loginForm').classList.add('active');
    document.querySelectorAll('.auth-tab')[0].classList.add('active');
}

function previewAvatar(input, previewId) {
    const file = input.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = e => {
            $(previewId).src = e.target.result;
            $(previewId).style.display = 'block';
        };
        reader.readAsDataURL(file);
    }
}

async function doLogin(e) {
    e.preventDefault();
    const form = e.target;
    const data = new FormData(form);
    try {
        const res = await fetch('?action=login', { method: 'POST', body: data });
        const json = await res.json();
        if (json.error) {
            $('loginError').textContent = json.error;
            $('loginError').style.display = 'block';
        } else {
            startApp();
        }
    } catch (err) {
        $('loginError').textContent = 'Erro de conexao';
        $('loginError').style.display = 'block';
    }
    return false;
}

async function doRegister(e) {
    e.preventDefault();
    const form = e.target;
    const data = new FormData(form);
    try {
        const res = await fetch('?action=register', { method: 'POST', body: data });
        const json = await res.json();
        if (json.error) {
            $('registerError').textContent = json.error;
            $('registerError').style.display = 'block';
            $('registerSuccess').style.display = 'none';
        } else {
            $('registerError').style.display = 'none';
            $('registerSuccess').textContent = json.message;
            $('registerSuccess').style.display = 'block';
            form.reset();
            $('regAvatarPreview').style.display = 'none';
            setTimeout(() => {
                const loginTab = document.querySelectorAll('.auth-tab')[0];
                showTab('login', loginTab);
            }, 2000);
        }
    } catch (err) {
        $('registerError').textContent = 'Erro de conexao';
        $('registerError').style.display = 'block';
    }
    return false;
}

async function doRecover(e) {
    e.preventDefault();
    const form = e.target;
    const data = new FormData(form);
    try {
        const res = await fetch('?action=recover', { method: 'POST', body: data });
        const json = await res.json();
        if (json.error) {
            $('recoverError').textContent = json.error;
            $('recoverError').style.display = 'block';
            $('recoverSuccess').style.display = 'none';
        } else {
            $('recoverError').style.display = 'none';
            $('recoverSuccess').textContent = json.message;
            $('recoverSuccess').style.display = 'block';
            form.reset();
        }
    } catch (err) {
        $('recoverError').textContent = 'Erro de conexao';
        $('recoverError').style.display = 'block';
    }
    return false;
}

async function doLogout() {
    await fetch('?action=logout');
    location.reload();
}

// ============================================================
// APP
// ============================================================
async function startApp() {
    $('authScreen').style.display = 'none';
    $('app').classList.add('active');

    const res = await fetch('?action=get_profile&user_id=0');
    const json = await res.json();
    if (json.profile) {
        currentUser = json.profile;
        currentRole = json.profile.role || 'user';
        updateUI();
    }

    await loadMessages();
    pollInterval = setInterval(doPoll, 1000);

    $('chatArea').addEventListener('scroll', () => {
        const area = $('chatArea');
        isAtBottom = area.scrollHeight - area.scrollTop - area.clientHeight < 50;
        if (isAtBottom) {
            newMessagesCount = 0;
            $('newMessagesBadge').style.display = 'none';
            $('scrollBottom').classList.remove('show');
        }
    });
}

function updateUI() {
    if (!currentUser) return;
    const avatarUrl = getAvatarUrl(currentUser.avatar);
    $('headerAvatar').src = avatarUrl;
    $('sideMenuAvatar').src = avatarUrl;
    $('sideMenuName').textContent = currentUser.username;

    // Mostra/oculta menus de admin
    if (currentRole === 'admin') {
        $('adminMenuItem').style.display = 'flex';
        $('viceAdminMenuItem').style.display = 'none';
    } else if (currentRole === 'vice_admin') {
        $('adminMenuItem').style.display = 'none';
        $('viceAdminMenuItem').style.display = 'flex';
    } else {
        $('adminMenuItem').style.display = 'none';
        $('viceAdminMenuItem').style.display = 'none';
    }
}

// ============================================================
// POLLING UNIFICADO
// ============================================================
async function doPoll() {
    try {
        const res = await fetch('?action=poll&last_id=' + lastMessageId);
        const json = await res.json();

        if (json.messages && json.messages.length > 0) {
            const wasAtBottom = isAtBottom;
            json.messages.forEach(msg => {
                renderMessage(msg, json.user_id);
                lastMessageId = Math.max(lastMessageId, msg.id);
            });
            if (wasAtBottom) {
                scrollToBottom();
            } else {
                newMessagesCount += json.messages.length;
                $('newMessagesBadge').textContent = newMessagesCount;
                $('newMessagesBadge').style.display = 'flex';
                $('scrollBottom').classList.add('show');
            }
        }

        if (json.online_count !== undefined) {
            $('onlineCount').textContent = json.online_count + ' online';
        }

        if (json.all_users) {
            cachedAllUsers = json.all_users;
        }

        // Chat locked status
        if (json.chat_locked !== undefined) {
            chatLocked = json.chat_locked;
            if (chatLocked && currentRole === 'user') {
                $('chatLockedBanner').classList.add('active');
                $('inputArea').style.display = 'none';
            } else {
                $('chatLockedBanner').classList.remove('active');
                $('inputArea').style.display = 'flex';
            }
        }

        // Muted status
        if (json.muted_until && json.muted_until > 0) {
            const remaining = Math.ceil((json.muted_until - Date.now()/1000) / 60);
            if (remaining > 0) {
                $('messageInput').placeholder = 'Silenciado por ' + remaining + ' min';
            } else {
                $('messageInput').placeholder = 'Mensagem';
            }
        }

    } catch (e) {}
}

// ============================================================
// MENSAGENS
// ============================================================
async function loadMessages() {
    try {
        const res = await fetch('?action=get_messages&last_id=' + lastMessageId);
        const json = await res.json();
        if (json.messages && json.messages.length > 0) {
            json.messages.forEach(msg => {
                renderMessage(msg, json.user_id);
                lastMessageId = Math.max(lastMessageId, msg.id);
            });
            scrollToBottom();
        }
        if (json.user_role) currentRole = json.user_role;
    } catch (e) {}
}

function renderMessage(msg, myUserId) {
    const isOwn = msg.user_id == myUserId;
    const msgDate = new Date(msg.created_at * 1000);
    const dateKey = msgDate.getFullYear() + '-' + msgDate.getMonth() + '-' + msgDate.getDate();

    if (lastDateSeparator !== dateKey) {
        lastDateSeparator = dateKey;
        const sep = document.createElement('div');
        sep.className = 'date-separator';
        sep.innerHTML = '<span>' + formatDateSeparator(msg.created_at) + '</span>';
        $('messagesContainer').appendChild(sep);
    }

    const wrapper = document.createElement('div');
    wrapper.className = 'message-wrapper ' + (isOwn ? 'own' : 'other');
    wrapper.dataset.msgId = msg.id;
    wrapper.dataset.userId = msg.user_id;

    let contentHtml = '';

    if (msg.reply_to) {
        const replyContent = msg.reply_content || 'Mensagem';
        contentHtml += `<div class="msg-reply" onclick="scrollToMessage(${msg.reply_to})">
            <div class="msg-reply-name">${escapeHtml(msg.reply_username || 'Alguem')}</div>
            <div class="msg-reply-text">${escapeHtml(replyContent.substring(0, 60))}</div>
        </div>`;
    }

    if (msg.deleted_for_all == '1') {
        contentHtml += '<span class="msg-deleted">🗑️ Esta mensagem foi excluida</span>';
    } else if (msg.type === 'image') {
        contentHtml += `<img src="${getFileUrl(msg.file_path)}" class="msg-image" onclick="openImageViewer('${getFileUrl(msg.file_path)}')" alt="">`;
        if (msg.content) contentHtml += `<div class="msg-content">${makeLinks(escapeHtml(msg.content))}</div>`;
    } else if (msg.type === 'audio') {
        contentHtml += `<div class="msg-audio"><span class="audio-icon">🎵</span><audio controls src="${getFileUrl(msg.file_path)}"></audio></div>`;
        if (msg.content) contentHtml += `<div class="msg-content">${makeLinks(escapeHtml(msg.content))}</div>`;
    } else if (msg.type === 'file') {
        contentHtml += `<a href="${getFileUrl(msg.file_path)}" download="${escapeHtml(msg.file_name)}" class="msg-file">
            <span class="file-icon">📄</span>
            <div class="file-info"><div class="file-name">${escapeHtml(msg.file_name)}</div><div class="file-size">${formatBytes(msg.file_size)}</div></div>
        </a>`;
        if (msg.content) contentHtml += `<div class="msg-content">${makeLinks(escapeHtml(msg.content))}</div>`;
    } else {
        contentHtml += `<div class="msg-content">${makeLinks(escapeHtml(msg.content))}</div>`;
    }

    let statusHtml = '';
    if (isOwn && msg.deleted_for_all != '1') {
        const viewers = msg.viewers ? msg.viewers.split(',') : [];
        const isViewed = viewers.length > 1;
        statusHtml = `<span class="msg-status ${isViewed ? 'viewed' : ''}" onclick="showViews(${msg.id}, event)" title="Ver quem visualizou">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                ${isViewed 
                    ? '<path d="M18 6L6 18M6 6l12 12" stroke-linecap="round" stroke-linejoin="round"/><path d="M20 6L8 18" stroke-linecap="round" stroke-linejoin="round"/>' 
                    : '<path d="M18 6L6 18M6 6l12 12" stroke-linecap="round" stroke-linejoin="round"/>'}
            </svg>
        </span>`;
    }

    const avatarHtml = !isOwn ? `<img src="${getAvatarUrl(msg.avatar)}" class="msg-avatar" onclick="showUserProfile(${msg.user_id})" alt="">` : '';
    const senderHtml = !isOwn ? `<div class="msg-sender" onclick="showUserProfile(${msg.user_id})">${escapeHtml(msg.username)}${msg.role !== 'user' ? getRoleBadge(msg.role) : ''}</div>` : '';

    wrapper.innerHTML = avatarHtml + `
        <div class="message" oncontextmenu="showContextMenu(event, ${msg.id}, ${msg.user_id}, ${isOwn ? 1 : 0})">
            ${senderHtml}
            ${contentHtml}
            <div class="msg-footer">
                <span class="msg-time">${formatTime(msg.created_at)}</span>
                ${statusHtml}
            </div>
        </div>
    `;

    $('messagesContainer').appendChild(wrapper);
}

// ============================================================
// ENVIO DE MENSAGENS
// ============================================================
async function sendMessage() {
    const input = $('messageInput');
    const content = input.value.trim();

    if (!content && !selectedFile) return;
    if (content.length > 1000) {
        showToast('Mensagem muito longa (max 1000 caracteres)');
        return;
    }

    const formData = new FormData();
    formData.append('content', content);
    if (replyToId) formData.append('reply_to', replyToId);
    if (selectedFile) formData.append('file', selectedFile);

    input.value = '';
    input.style.height = 'auto';
    updateCharCount(input);
    cancelReply();
    cancelFile();

    try {
        const res = await fetch('?action=send_message', { method: 'POST', body: formData });
        const json = await res.json();
        if (json.error) showToast(json.error);
    } catch (e) {
        showToast('Erro ao enviar mensagem');
    }
}

function handleKeyDown(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
    }
}

function autoResize(textarea) {
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 100) + 'px';
}

function updateCharCount(textarea) {
    $('charCount').textContent = textarea.value.length + '/1000';
}

// ============================================================
// GRAVACAO DE AUDIO
// ============================================================
async function toggleRecording() {
    if (isRecording) {
        stopRecording();
    } else {
        await startRecording();
    }
}

async function startRecording() {
    if (isRecording) return;
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRecorder = new MediaRecorder(stream);
        recordedChunks = [];
        mediaRecorder.ondataavailable = (e) => {
            if (e.data.size > 0) recordedChunks.push(e.data);
        };
        mediaRecorder.onstop = () => {
            const blob = new Blob(recordedChunks, { type: 'audio/webm' });
            if (blob.size > 0) {
                const file = new File([blob], 'audio_' + Date.now() + '.webm', { type: 'audio/webm' });
                sendAudioFile(file);
            }
            stream.getTracks().forEach(t => t.stop());
        };
        mediaRecorder.start();
        isRecording = true;
        recordingStartTime = Date.now();
        $('recordBtn').classList.add('recording');
        $('recordingOverlay').classList.add('active');
        $('sendBtn').style.display = 'none';
        recordingTimer = setInterval(updateRecordingTime, 1000);
    } catch (err) {
        showToast('Permissao de microfone negada');
    }
}

function stopRecording() {
    if (!isRecording || !mediaRecorder) return;
    isRecording = false;
    clearInterval(recordingTimer);
    if (mediaRecorder.state !== 'inactive') mediaRecorder.stop();
    $('recordBtn').classList.remove('recording');
    $('recordingOverlay').classList.remove('active');
    $('sendBtn').style.display = 'flex';
    $('recordingTime').textContent = '00:00';
}

function updateRecordingTime() {
    const elapsed = Math.floor((Date.now() - recordingStartTime) / 1000);
    const mins = String(Math.floor(elapsed / 60)).padStart(2, '0');
    const secs = String(elapsed % 60).padStart(2, '0');
    $('recordingTime').textContent = mins + ':' + secs;
}

async function sendAudioFile(file) {
    if (file.size > 20 * 1024 * 1024) {
        showToast('Audio muito grande (max 20MB)');
        return;
    }
    const formData = new FormData();
    formData.append('content', '');
    formData.append('file', file);
    if (replyToId) formData.append('reply_to', replyToId);
    cancelReply();
    try {
        const res = await fetch('?action=send_message', { method: 'POST', body: formData });
        const json = await res.json();
        if (json.error) showToast(json.error);
    } catch (e) {
        showToast('Erro ao enviar audio');
    }
}

// ============================================================
// CAMERA
// ============================================================
async function openCamera() {
    try {
        currentCameraFacing = 'environment';
        cameraStream = await navigator.mediaDevices.getUserMedia({ 
            video: { facingMode: 'environment' }, audio: false 
        });
        $('cameraVideo').srcObject = cameraStream;
        $('cameraOverlay').classList.add('active');
    } catch (err) {
        showToast('Permissao de camera negada');
    }
}

async function flipCamera() {
    if (!cameraStream) return;
    cameraStream.getTracks().forEach(t => t.stop());
    currentCameraFacing = currentCameraFacing === 'environment' ? 'user' : 'environment';
    try {
        cameraStream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: currentCameraFacing }, audio: false
        });
        $('cameraVideo').srcObject = cameraStream;
    } catch (err) {
        showToast('Nao foi possivel alternar a camera');
        currentCameraFacing = currentCameraFacing === 'environment' ? 'user' : 'environment';
        try {
            cameraStream = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: currentCameraFacing }, audio: false
            });
            $('cameraVideo').srcObject = cameraStream;
        } catch (e2) {}
    }
}

function closeCamera() {
    if (cameraStream) {
        cameraStream.getTracks().forEach(t => t.stop());
        cameraStream = null;
    }
    $('cameraOverlay').classList.remove('active');
}

function takePhoto() {
    const video = $('cameraVideo');
    const canvas = $('cameraCanvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0);
    canvas.toBlob((blob) => {
        const file = new File([blob], 'photo_' + Date.now() + '.jpg', { type: 'image/jpeg' });
        closeCamera();
        if (file.size > 10 * 1024 * 1024) {
            showToast('Foto muito grande (max 10MB)');
            return;
        }
        const formData = new FormData();
        formData.append('content', '');
        formData.append('file', file);
        if (replyToId) formData.append('reply_to', replyToId);
        cancelReply();
        fetch('?action=send_message', { method: 'POST', body: formData })
            .then(r => r.json())
            .then(json => { if (json.error) showToast(json.error); })
            .catch(() => showToast('Erro ao enviar foto'));
    }, 'image/jpeg', 0.9);
}

// ============================================================
// ARQUIVOS
// ============================================================
function onFileSelected(input) {
    const file = input.files[0];
    if (!file) return;
    const maxSize = file.type.startsWith('image/') ? 10 * 1024 * 1024 : 20 * 1024 * 1024;
    if (file.size > maxSize) {
        showToast('Arquivo muito grande! Max: ' + (maxSize / 1024 / 1024) + 'MB');
        input.value = '';
        return;
    }
    selectedFile = file;
    $('filePreviewName').textContent = file.name + ' (' + formatBytes(file.size) + ')';
    $('filePreview').classList.add('active');
}

function cancelFile() {
    selectedFile = null;
    $('filePreview').classList.remove('active');
    $('fileInput').value = '';
}

// ============================================================
// REPLY
// ============================================================
function replyToMessage() {
    if (!contextMsgId) return;
    replyToId = contextMsgId;
    const msgEl = document.querySelector(`[data-msg-id="${contextMsgId}"]`);
    if (msgEl) {
        const content = msgEl.querySelector('.msg-content')?.textContent || '';
        const sender = msgEl.querySelector('.msg-sender')?.textContent || 'Alguem';
        $('replyPreviewText').textContent = sender + ': ' + content.substring(0, 50);
        $('replyPreview').classList.add('active');
    }
    hideContextMenu();
    $('messageInput').focus();
}

function cancelReply() {
    replyToId = null;
    $('replyPreview').classList.remove('active');
}

function scrollToMessage(msgId) {
    const el = document.querySelector(`[data-msg-id="${msgId}"]`);
    if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        el.style.background = 'rgba(18,140,126,0.2)';
        setTimeout(() => el.style.background = '', 1500);
    }
}

// ============================================================
// CONTEXT MENU
// ============================================================
function showContextMenu(e, msgId, userId, isOwn) {
    e.preventDefault();
    contextMsgId = msgId;
    contextMsgUserId = userId;
    contextMsgIsOwn = isOwn;

    const menu = $('contextMenu');
    const deleteAllItem = $('deleteForAllItem');
    const adminDivider = $('adminContextDivider');
    const adminDeleteItem = $('adminDeleteMsgItem');

    if (isOwn) {
        deleteAllItem.style.display = 'flex';
    } else {
        deleteAllItem.style.display = 'none';
    }

    // Mostra opções de admin para mensagens de outros
    if (!isOwn && (currentRole === 'admin' || currentRole === 'vice_admin')) {
        adminDivider.style.display = 'block';
        adminDeleteItem.style.display = 'flex';
    } else {
        adminDivider.style.display = 'none';
        adminDeleteItem.style.display = 'none';
    }

    menu.style.display = 'block';
    menu.style.left = e.pageX + 'px';
    menu.style.top = e.pageY + 'px';

    const rect = menu.getBoundingClientRect();
    if (rect.right > window.innerWidth) menu.style.left = (e.pageX - rect.width) + 'px';
    if (rect.bottom > window.innerHeight) menu.style.top = (e.pageY - rect.height) + 'px';
}

function hideContextMenu() {
    $('contextMenu').style.display = 'none';
}

document.addEventListener('click', hideContextMenu);

function copyMessage() {
    if (!contextMsgId) return;
    const msgEl = document.querySelector(`[data-msg-id="${contextMsgId}"]`);
    if (msgEl) {
        const text = msgEl.querySelector('.msg-content')?.textContent || '';
        navigator.clipboard.writeText(text).then(() => showToast('Copiado!'));
    }
    hideContextMenu();
}

async function deleteForMe() {
    if (!contextMsgId) return;
    try {
        const formData = new FormData();
        formData.append('message_id', contextMsgId);
        formData.append('for_all', '0');
        await fetch('?action=delete_message', { method: 'POST', body: formData });
        const el = document.querySelector(`[data-msg-id="${contextMsgId}"]`);
        if (el) el.remove();
        showToast('Mensagem excluida');
    } catch (e) {}
    hideContextMenu();
}

async function deleteForAll() {
    if (!contextMsgId) return;
    try {
        const formData = new FormData();
        formData.append('message_id', contextMsgId);
        formData.append('for_all', '1');
        await fetch('?action=delete_message', { method: 'POST', body: formData });
        const el = document.querySelector(`[data-msg-id="${contextMsgId}"]`);
        if (el) {
            const content = el.querySelector('.message');
            content.innerHTML = '<span class="msg-deleted">🗑️ Esta mensagem foi excluida</span>';
        }
        showToast('Mensagem excluida para todos');
    } catch (e) {}
    hideContextMenu();
}

// Admin delete message from context menu
async function adminDeleteMessage() {
    if (!contextMsgId) return;
    try {
        const formData = new FormData();
        formData.append('message_id', contextMsgId);
        await fetch('?action=admin_delete_message', { method: 'POST', body: formData });
        const el = document.querySelector(`[data-msg-id="${contextMsgId}"]`);
        if (el) {
            const content = el.querySelector('.message');
            content.innerHTML = '<span class="msg-deleted">🗑️ Esta mensagem foi excluida pelo admin</span>';
        }
        showToast('Mensagem apagada pelo admin');
    } catch (e) {}
    hideContextMenu();
}

// ============================================================
// VISUALIZACOES
// ============================================================
async function showViews(msgId, e) {
    e.stopPropagation();
    try {
        const res = await fetch('?action=get_views&message_id=' + msgId);
        const json = await res.json();
        const list = $('viewsList');
        list.innerHTML = '';

        if (json.views && json.views.length > 0) {
            json.views.forEach(v => {
                const item = document.createElement('div');
                item.className = 'view-item';
                item.innerHTML = `
                    <img src="${getAvatarUrl(v.avatar)}" alt="">
                    <div class="view-item-info">
                        <div class="view-item-name">${escapeHtml(v.username)}</div>
                        <div class="view-item-time">${formatTime(v.viewed_at)}</div>
                    </div>
                `;
                list.appendChild(item);
            });
        } else {
            list.innerHTML = '<div style="padding:20px;text-align:center;color:#999">Ninguem visualizou ainda</div>';
        }

        $('viewsModal').classList.add('active');
    } catch (e) {}
}

// ============================================================
// PERFIS
// ============================================================
async function showUserProfile(userId) {
    try {
        const res = await fetch('?action=get_profile&user_id=' + userId);
        const json = await res.json();
        if (json.profile) {
            renderProfile(json.profile);
            $('profileModal').classList.add('active');
        }
    } catch (e) {}
}

async function showMyProfile() {
    if (!currentUser) return;
    try {
        const res = await fetch('?action=get_profile&user_id=' + currentUser.id);
        const json = await res.json();
        if (json.profile) {
            renderProfile(json.profile);
            $('profileModal').classList.add('active');
        }
    } catch (e) {}
}

function renderProfile(profile) {
    $('profileAvatar').src = getAvatarUrl(profile.avatar);
    $('profileName').innerHTML = escapeHtml(profile.username) + (profile.role !== 'user' ? ' ' + getRoleBadge(profile.role) : '');
    $('profileDescription').textContent = profile.description || 'Sem descricao';
    $('profileCountry').textContent = profile.country || 'Nao informado';
    $('profileLanguage').textContent = profile.language || 'Nao informado';
    $('profileJoined').textContent = new Date(profile.created_at * 1000).toLocaleDateString('pt-BR');
}

function showEditProfile() {
    if (!currentUser) return;
    $('editDescription').value = currentUser.description || '';
    $('editCountry').value = currentUser.country || '';
    $('editLanguage').value = currentUser.language || '';
    if (currentUser.avatar) {
        $('editAvatarPreview').src = getAvatarUrl(currentUser.avatar);
        $('editAvatarPreview').style.display = 'block';
    }
    $('editProfileModal').classList.add('active');
}

async function saveProfile(e) {
    e.preventDefault();
    const form = e.target;
    const data = new FormData(form);
    try {
        const res = await fetch('?action=update_profile', { method: 'POST', body: data });
        const json = await res.json();
        if (json.success) {
            showToast('Perfil atualizado!');
            hideModal('editProfileModal');
            const pres = await fetch('?action=get_profile&user_id=' + currentUser.id);
            const pjson = await pres.json();
            if (pjson.profile) {
                currentUser = pjson.profile;
                updateUI();
            }
        }
    } catch (e) {}
    return false;
}

// ============================================================
// TODOS OS USUARIOS
// ============================================================
function showAllUsers() {
    const list = $('allUsersList');
    list.innerHTML = '';

    if (cachedAllUsers && cachedAllUsers.length > 0) {
        cachedAllUsers.forEach(u => {
            const isOnline = (Date.now() / 1000) - u.last_seen < 60;
            const item = document.createElement('div');
            item.className = 'all-user-item';
            item.innerHTML = `
                <img src="${getAvatarUrl(u.avatar)}" alt="">
                <div class="all-user-info">
                    <div class="all-user-name">${escapeHtml(u.username)}${u.role !== 'user' ? getRoleBadge(u.role) : ''}</div>
                    <div class="all-user-status">${isOnline ? 'online' : formatLastSeen(u.last_seen)}</div>
                </div>
                <span class="all-user-dot ${isOnline ? 'online' : 'offline'}"></span>
            `;
            item.onclick = () => { hideModal('allUsersModal'); showUserProfile(u.id); };
            list.appendChild(item);
        });
    } else {
        list.innerHTML = '<div style="padding:20px;text-align:center;color:#999">Nenhum usuario encontrado</div>';
    }

    $('allUsersModal').classList.add('active');
}

// ============================================================
// MODAIS E UI
// ============================================================
function hideModal(id) {
    if (id) $(id).classList.remove('active');
}

function closeModal(e, id) {
    if (e.target === $(id)) $(id).classList.remove('active');
}

function openImageViewer(src) {
    $('imageViewerImg').src = src;
    $('imageViewer').classList.add('active');
}

function closeImageViewer() {
    $('imageViewer').classList.remove('active');
}

function scrollToBottom() {
    const area = $('chatArea');
    area.scrollTop = area.scrollHeight;
    isAtBottom = true;
    newMessagesCount = 0;
    $('newMessagesBadge').style.display = 'none';
    $('scrollBottom').classList.remove('show');
}

function toggleSideMenu() {
    $('sideMenu').classList.toggle('open');
    $('sideMenuOverlay').classList.toggle('active');
}

// ============================================================
// ADMIN PANEL - ADMIN GERAL
// ============================================================
function showAdminPanel() {
    $('adminPanelModal').classList.add('active');
    adminLoadStats();
    adminLoadUsers();
}

async function adminLoadStats() {
    try {
        const res = await fetch('?action=admin_stats');
        const stats = await res.json();
        const statsDiv = $('adminStats');
        statsDiv.innerHTML = `
            <div class="admin-stat"><div class="admin-stat-value">${stats.total_users}</div><div class="admin-stat-label">Usuários</div></div>
            <div class="admin-stat"><div class="admin-stat-value">${stats.total_messages}</div><div class="admin-stat-label">Mensagens</div></div>
            <div class="admin-stat"><div class="admin-stat-value">${stats.banned_users}</div><div class="admin-stat-label">Banidos</div></div>
            <div class="admin-stat"><div class="admin-stat-value">${stats.online_users}</div><div class="admin-stat-label">Online</div></div>
        `;
        $('adminToggleChatBtn').textContent = stats.chat_locked ? '🔓 Abrir Chat' : '🔒 Fechar Chat';
    } catch (e) {}
}

async function adminLoadUsers() {
    try {
        const res = await fetch('?action=admin_list_users');
        const json = await res.json();
        adminUsersCache = json.users || [];
        renderAdminUsers(adminUsersCache, 'adminUsersList', true);
        $('adminLogsList').style.display = 'none';
        $('adminUsersList').style.display = 'block';
    } catch (e) {}
}

function renderAdminUsers(users, containerId, isAdmin) {
    const container = $(containerId);
    container.innerHTML = '';

    if (!users || users.length === 0) {
        container.innerHTML = '<div style="padding:20px;text-align:center;color:#999">Nenhum usuario</div>';
        return;
    }

    users.forEach(u => {
        const isOnline = (Date.now() / 1000) - u.last_seen < 60;
        const isBanned = u.is_banned == '1';
        const isMuted = u.muted_until > (Date.now() / 1000);
        const item = document.createElement('div');
        item.className = 'admin-user-item';

        let actions = '';
        if (isAdmin) {
            actions = `
                <div class="admin-user-actions">
                    <button class="btn btn-sm btn-secondary" onclick="adminEditUser(${u.id})">✏️ Editar</button>
                    ${!isBanned ? `<button class="btn btn-sm btn-danger" onclick="adminBanUser(${u.id})">🚫 Banir</button>` : `<button class="btn btn-sm btn-primary" onclick="adminUnbanUser(${u.id})">✅ Desbanir</button>`}
                    ${!isMuted ? `<button class="btn btn-sm btn-secondary" onclick="adminMuteUser(${u.id})">🔇 Silenciar</button>` : `<button class="btn btn-sm btn-primary" onclick="adminUnmuteUser(${u.id})">🔊 Dessilenciar</button>`}
                    <button class="btn btn-sm btn-danger" onclick="adminDeleteAvatar(${u.id})">🖼️ Apagar Foto</button>
                </div>
            `;
        } else {
            // Vice-admin - mais limitado
            actions = `
                <div class="admin-user-actions">
                    ${!isBanned ? `<button class="btn btn-sm btn-danger" onclick="adminBanUser(${u.id})">🚫 Banir</button>` : `<button class="btn btn-sm btn-primary" onclick="adminUnbanUser(${u.id})">✅ Desbanir</button>`}
                    ${!isMuted ? `<button class="btn btn-sm btn-secondary" onclick="adminMuteUser(${u.id})">🔇 Silenciar</button>` : `<button class="btn btn-sm btn-primary" onclick="adminUnmuteUser(${u.id})">🔊 Dessilenciar</button>`}
                </div>
            `;
        }

        item.innerHTML = `
            <img src="${getAvatarUrl(u.avatar)}" alt="">
            <div class="admin-user-info">
                <div class="admin-user-name">${escapeHtml(u.username)}${u.role !== 'user' ? getRoleBadge(u.role) : ''} ${isBanned ? '<span style="color:var(--danger)">[BANIDO]</span>' : ''} ${isMuted ? '<span style="color:orange">[SILENCIADO]</span>' : ''}</div>
                <div class="admin-user-meta">${isOnline ? 'online' : formatLastSeen(u.last_seen)} | ${u.country || 'Sem país'}</div>
            </div>
            ${actions}
        `;
        container.appendChild(item);
    });
}

async function adminToggleChat() {
    try {
        const res = await fetch('?action=admin_toggle_chat', { method: 'POST' });
        const json = await res.json();
        if (json.success) {
            showToast(json.locked ? 'Chat fechado!' : 'Chat aberto!');
            adminLoadStats();
        }
    } catch (e) {}
}

async function adminBanUser(userId) {
    const duration = prompt('Duracao do ban em minutos (0 = permanente):', '60');
    if (duration === null) return;
    const banIP = confirm('Banir IP tambem? (apenas Admin Geral)');
    try {
        const formData = new FormData();
        formData.append('user_id', userId);
        formData.append('duration', duration);
        formData.append('ban_ip', banIP ? '1' : '0');
        const res = await fetch('?action=admin_ban_user', { method: 'POST', body: formData });
        const json = await res.json();
        if (json.success) {
            showToast('Usuario banido!');
            adminLoadUsers();
            viceAdminLoadUsers();
        } else {
            showToast(json.error || 'Erro');
        }
    } catch (e) {}
}

async function adminUnbanUser(userId) {
    try {
        const formData = new FormData();
        formData.append('user_id', userId);
        const res = await fetch('?action=admin_unban_user', { method: 'POST', body: formData });
        const json = await res.json();
        if (json.success) {
            showToast('Usuario desbanido!');
            adminLoadUsers();
            viceAdminLoadUsers();
        }
    } catch (e) {}
}

async function adminMuteUser(userId) {
    const duration = prompt('Duracao do silencio em minutos (0 = permanente):', '60');
    if (duration === null) return;
    try {
        const formData = new FormData();
        formData.append('user_id', userId);
        formData.append('duration', duration);
        const res = await fetch('?action=admin_mute_user', { method: 'POST', body: formData });
        const json = await res.json();
        if (json.success) {
            showToast('Usuario silenciado!');
            adminLoadUsers();
            viceAdminLoadUsers();
        } else {
            showToast(json.error || 'Erro');
        }
    } catch (e) {}
}

async function adminUnmuteUser(userId) {
    try {
        const formData = new FormData();
        formData.append('user_id', userId);
        const res = await fetch('?action=admin_unmute_user', { method: 'POST', body: formData });
        const json = await res.json();
        if (json.success) {
            showToast('Silencio removido!');
            adminLoadUsers();
            viceAdminLoadUsers();
        }
    } catch (e) {}
}

async function adminDeleteAvatar(userId) {
    if (!confirm('Tem certeza que deseja apagar a foto deste usuario?')) return;
    try {
        const formData = new FormData();
        formData.append('user_id', userId);
        const res = await fetch('?action=admin_delete_avatar', { method: 'POST', body: formData });
        const json = await res.json();
        if (json.success) {
            showToast('Avatar apagado!');
            adminLoadUsers();
        }
    } catch (e) {}
}

function adminEditUser(userId) {
    const user = adminUsersCache.find(u => u.id == userId);
    if (!user) return;
    $('editTargetUserId').value = userId;
    $('editTargetUsername').value = user.username;
    $('editTargetDescription').value = user.description || '';
    $('editTargetCountry').value = user.country || '';
    $('editTargetLanguage').value = user.language || '';
    $('editTargetRole').value = user.role || 'user';
    $('adminEditUserModal').classList.add('active');
}

async function adminSaveUser(e) {
    e.preventDefault();
    const form = e.target;
    const data = new FormData(form);
    data.append('user_id', $('editTargetUserId').value);
    try {
        const res = await fetch('?action=admin_edit_user', { method: 'POST', body: data });
        const json = await res.json();
        if (json.success) {
            showToast('Usuario atualizado!');
            hideModal('adminEditUserModal');
            adminLoadUsers();
        } else {
            showToast(json.error || 'Erro');
        }
    } catch (e) {}
    return false;
}

async function adminLoadLogs() {
    try {
        const res = await fetch('?action=admin_logs');
        const json = await res.json();
        const container = $('adminLogsList');
        container.innerHTML = '';

        if (json.logs && json.logs.length > 0) {
            json.logs.forEach(l => {
                const item = document.createElement('div');
                item.className = 'admin-log-item';
                item.innerHTML = `
                    <div><strong>${escapeHtml(l.admin_name || 'Admin')}</strong> - ${escapeHtml(l.action)}</div>
                    <div>Alvo: ${escapeHtml(l.target_name || 'N/A')} | ${escapeHtml(l.details || '')}</div>
                    <div class="admin-log-time">${new Date(l.created_at * 1000).toLocaleString('pt-BR')}</div>
                `;
                container.appendChild(item);
            });
        } else {
            container.innerHTML = '<div style="padding:20px;text-align:center;color:#999">Nenhum log</div>';
        }

        $('adminUsersList').style.display = 'none';
        $('adminLogsList').style.display = 'block';
    } catch (e) {}
}

// ============================================================
// VICE ADMIN PANEL
// ============================================================
function showViceAdminPanel() {
    $('viceAdminPanelModal').classList.add('active');
    viceAdminLoadUsers();
}

async function viceAdminLoadUsers() {
    try {
        const res = await fetch('?action=admin_list_users');
        const json = await res.json();
        // Filtra: vice-admin não vê outros vice-admins nem admin
        const filtered = (json.users || []).filter(u => u.role === 'user');
        renderAdminUsers(filtered, 'viceAdminUsersList', false);
    } catch (e) {}
}

// ============================================================
// INICIALIZACAO
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
    fetch('?action=ping')
        .then(r => r.json())
        .then(json => {
            if (json.ok) startApp();
        })
        .catch(() => {});
});

window.addEventListener('beforeunload', () => {
    if (pollInterval) clearInterval(pollInterval);
    if (isRecording) stopRecording();
    if (cameraStream) cameraStream.getTracks().forEach(t => t.stop());
    navigator.sendBeacon('?action=logout');
});
</script>
</body>
</html>
