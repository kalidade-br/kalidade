<?php
/**
 * Painel Administrativo - UniChat
 * Requer: PHP 7.4+ com extensão PDO SQLite
 */

session_start();

// ============================================================
// CONFIGURAÇÕES
// ============================================================
define('DB_PATH', __DIR__ . '/unichat.db');
define('ADMIN_PASSWORD', 'admin123'); // Mude isso em produção!

// ============================================================
// CONEXÃO COM BANCO
// ============================================================
try {
    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erro ao conectar ao banco: " . $e->getMessage());
}

// ============================================================
// FUNÇÕES AUXILIARES
// ============================================================
function logAdminAction($adminId, $action, $targetUserId = null, $details = '') {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO admin_logs (admin_id, action, target_user_id, details, created_at) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$adminId, $action, $targetUserId, $details, time()]);
}

function redirect($url) {
    header("Location: $url");
    exit;
}

function sanitize($str) {
    return htmlspecialchars(trim($str), ENT_QUOTES, 'UTF-8');
}

// ============================================================
// AUTENTICAÇÃO SIMPLES
// ============================================================
$isLogged = isset($_SESSION['admin_logged']) && $_SESSION['admin_logged'] === true;

if (isset($_GET['logout'])) {
    session_destroy();
    redirect('painel.php');
}

if (!$isLogged && isset($_POST['login'])) {
    $pass = $_POST['password'] ?? '';
    // Verifica se existe um usuário admin no banco ou usa a senha padrão
    $stmt = $pdo->query("SELECT * FROM users WHERE role = 'admin' LIMIT 1");
    $adminUser = $stmt->fetch();

    $valid = false;
    if ($adminUser && password_verify($pass, $adminUser['password_hash'])) {
        $_SESSION['admin_id'] = $adminUser['id'];
        $valid = true;
    } elseif ($pass === ADMIN_PASSWORD) {
        $_SESSION['admin_id'] = $adminUser['id'] ?? 1;
        $valid = true;
    }

    if ($valid) {
        $_SESSION['admin_logged'] = true;
        redirect('painel.php');
    } else {
        $loginError = "Senha incorreta!";
    }
}

// ============================================================
// AÇÕES (requer login)
// ============================================================
$msg = '';
$err = '';

if ($isLogged) {
    $adminId = $_SESSION['admin_id'] ?? 1;

    // --- EDITAR USUÁRIO ---
    if (isset($_POST['edit_user'])) {
        $userId = (int)($_POST['user_id'] ?? 0);
        $newUsername = trim($_POST['username'] ?? '');
        $newPassword = trim($_POST['password'] ?? '');
        $newRole = in_array($_POST['role'] ?? '', ['user','vice_admin','admin']) ? $_POST['role'] : 'user';
        $newStatus = in_array($_POST['status'] ?? '', ['online','offline','away']) ? $_POST['status'] : 'offline';

        if ($userId <= 0 || empty($newUsername)) {
            $err = "Dados inválidos para o usuário.";
        } else {
            try {
                // Verifica se username já existe em outro usuário
                $check = $pdo->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
                $check->execute([$newUsername, $userId]);
                if ($check->fetch()) {
                    $err = "Username já está em uso por outro usuário.";
                } else {
                    if (!empty($newPassword)) {
                        $hash = password_hash($newPassword, PASSWORD_DEFAULT);
                        $stmt = $pdo->prepare("UPDATE users SET username = ?, password_hash = ?, role = ?, status = ? WHERE id = ?");
                        $stmt->execute([$newUsername, $hash, $newRole, $newStatus, $userId]);
                        logAdminAction($adminId, 'update_user_password', $userId, "Username: $newUsername, Role: $newRole");
                    } else {
                        $stmt = $pdo->prepare("UPDATE users SET username = ?, role = ?, status = ? WHERE id = ?");
                        $stmt->execute([$newUsername, $newRole, $newStatus, $userId]);
                        logAdminAction($adminId, 'update_user', $userId, "Username: $newUsername, Role: $newRole");
                    }
                    // Atualiza username nas mensagens também para manter consistência visual
                    $pdo->prepare("UPDATE messages SET username = ? WHERE user_id = ?")
                        ->execute([$newUsername, $userId]);
                    $msg = "Usuário #$userId atualizado com sucesso!";
                }
            } catch (PDOException $e) {
                $err = "Erro ao atualizar: " . $e->getMessage();
            }
        }
    }

    // --- BANIR/DESBANIR USUÁRIO ---
    if (isset($_GET['ban_user'])) {
        $userId = (int)$_GET['ban_user'];
        $stmt = $pdo->prepare("UPDATE users SET is_banned = 1, banned_until = ? WHERE id = ?");
        $stmt->execute([time() + (86400 * 30), $userId]); // Ban 30 dias
        logAdminAction($adminId, 'ban_user', $userId, "Banido por 30 dias");
        $msg = "Usuário #$userId banido por 30 dias.";
    }

    if (isset($_GET['unban_user'])) {
        $userId = (int)$_GET['unban_user'];
        $stmt = $pdo->prepare("UPDATE users SET is_banned = 0, banned_until = 0 WHERE id = ?");
        $stmt->execute([$userId]);
        logAdminAction($adminId, 'unban_user', $userId, "Desbanido");
        $msg = "Usuário #$userId desbanido.";
    }

    // --- EDITAR MENSAGEM ---
    if (isset($_POST['edit_message'])) {
        $msgId = (int)($_POST['message_id'] ?? 0);
        $newContent = trim($_POST['content'] ?? '');

        if ($msgId <= 0) {
            $err = "ID da mensagem inválido.";
        } else {
            try {
                $stmt = $pdo->prepare("UPDATE messages SET content = ? WHERE id = ?");
                $stmt->execute([$newContent, $msgId]);
                logAdminAction($adminId, 'edit_message', null, "Mensagem #$msgId editada");
                $msg = "Mensagem #$msgId atualizada!";
            } catch (PDOException $e) {
                $err = "Erro ao editar mensagem: " . $e->getMessage();
            }
        }
    }

    // --- DELETAR MENSAGEM (soft delete) ---
    if (isset($_GET['delete_message'])) {
        $msgId = (int)$_GET['delete_message'];
        $stmt = $pdo->prepare("UPDATE messages SET deleted_for_all = 1 WHERE id = ?");
        $stmt->execute([$msgId]);
        logAdminAction($adminId, 'delete_message', null, "Mensagem #$msgId deletada");
        $msg = "Mensagem #$msgId removida.";
    }

    // --- RESTAURAR MENSAGEM ---
    if (isset($_GET['restore_message'])) {
        $msgId = (int)$_GET['restore_message'];
        $stmt = $pdo->prepare("UPDATE messages SET deleted_for_all = 0 WHERE id = ?");
        $stmt->execute([$msgId]);
        logAdminAction($adminId, 'restore_message', null, "Mensagem #$msgId restaurada");
        $msg = "Mensagem #$msgId restaurada.";
    }
}

// ============================================================
// DADOS PARA EXIBIÇÃO
// ============================================================
$users = [];
$messages = [];
$totalUsers = 0;
$totalMessages = 0;
$editUser = null;
$editMessage = null;

if ($isLogged) {
    // Busca usuários
    $searchUser = trim($_GET['search_user'] ?? '');
    if ($searchUser) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username LIKE ? OR id = ? ORDER BY id DESC");
        $stmt->execute(["%$searchUser%", is_numeric($searchUser) ? (int)$searchUser : 0]);
    } else {
        $stmt = $pdo->query("SELECT * FROM users ORDER BY id DESC LIMIT 100");
    }
    $users = $stmt->fetchAll();
    $totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();

    // Busca mensagens
    $searchMsg = trim($_GET['search_msg'] ?? '');
    if ($searchMsg) {
        $stmt = $pdo->prepare("SELECT m.*, u.username as real_username FROM messages m LEFT JOIN users u ON m.user_id = u.id WHERE m.content LIKE ? OR m.id = ? ORDER BY m.id DESC LIMIT 100");
        $stmt->execute(["%$searchMsg%", is_numeric($searchMsg) ? (int)$searchMsg : 0]);
    } else {
        $stmt = $pdo->query("SELECT m.*, u.username as real_username FROM messages m LEFT JOIN users u ON m.user_id = u.id ORDER BY m.id DESC LIMIT 100");
    }
    $messages = $stmt->fetchAll();
    $totalMessages = $pdo->query("SELECT COUNT(*) FROM messages")->fetchColumn();

    // Carrega usuário para edição
    if (isset($_GET['edit_user'])) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([(int)$_GET['edit_user']]);
        $editUser = $stmt->fetch();
    }

    // Carrega mensagem para edição
    if (isset($_GET['edit_message'])) {
        $stmt = $pdo->prepare("SELECT * FROM messages WHERE id = ?");
        $stmt->execute([(int)$_GET['edit_message']]);
        $editMessage = $stmt->fetch();
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UniChat - Painel Administrativo</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #0f0f23;
            color: #e0e0e0;
            min-height: 100vh;
        }
        .container { max-width: 1400px; margin: 0 auto; padding: 20px; }
        header {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            border: 1px solid #2a2a4a;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        header h1 { color: #00d4ff; font-size: 24px; }
        header .stats { display: flex; gap: 20px; font-size: 14px; color: #888; }
        header .stats span { color: #00d4ff; font-weight: bold; }
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 13px;
            text-decoration: none;
            display: inline-block;
            transition: all 0.2s;
        }
        .btn-primary { background: #00d4ff; color: #0f0f23; }
        .btn-primary:hover { background: #00a8cc; }
        .btn-danger { background: #ff4757; color: white; }
        .btn-danger:hover { background: #cc3845; }
        .btn-warning { background: #ffa502; color: #0f0f23; }
        .btn-warning:hover { background: #cc8400; }
        .btn-success { background: #2ed573; color: #0f0f23; }
        .btn-success:hover { background: #25aa5c; }
        .btn-sm { padding: 4px 10px; font-size: 12px; }

        .alert {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 16px;
            font-size: 14px;
        }
        .alert-success { background: rgba(46, 213, 115, 0.15); border: 1px solid #2ed573; color: #2ed573; }
        .alert-error { background: rgba(255, 71, 87, 0.15); border: 1px solid #ff4757; color: #ff4757; }

        .card {
            background: #1a1a2e;
            border: 1px solid #2a2a4a;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .card h2 { color: #00d4ff; margin-bottom: 16px; font-size: 18px; display: flex; align-items: center; gap: 8px; }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }
        th, td {
            padding: 10px 12px;
            text-align: left;
            border-bottom: 1px solid #2a2a4a;
        }
        th { color: #888; font-weight: 600; text-transform: uppercase; font-size: 11px; letter-spacing: 0.5px; }
        tr:hover { background: rgba(0, 212, 255, 0.03); }
        .text-muted { color: #666; }
        .badge {
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 600;
        }
        .badge-admin { background: rgba(0, 212, 255, 0.2); color: #00d4ff; }
        .badge-user { background: rgba(142, 142, 160, 0.2); color: #8e8ea0; }
        .badge-vice { background: rgba(255, 165, 2, 0.2); color: #ffa502; }
        .badge-banned { background: rgba(255, 71, 87, 0.2); color: #ff4757; }
        .badge-online { background: rgba(46, 213, 115, 0.2); color: #2ed573; }

        .search-box {
            display: flex;
            gap: 10px;
            margin-bottom: 16px;
        }
        .search-box input {
            flex: 1;
            padding: 10px 14px;
            background: #0f0f23;
            border: 1px solid #2a2a4a;
            border-radius: 8px;
            color: #e0e0e0;
            font-size: 14px;
        }
        .search-box input:focus { outline: none; border-color: #00d4ff; }

        .form-group { margin-bottom: 14px; }
        .form-group label { display: block; margin-bottom: 6px; font-size: 13px; color: #888; }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 10px 14px;
            background: #0f0f23;
            border: 1px solid #2a2a4a;
            border-radius: 8px;
            color: #e0e0e0;
            font-size: 14px;
        }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            outline: none; border-color: #00d4ff;
        }
        .form-group small { color: #666; font-size: 12px; }

        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        @media (max-width: 900px) { .grid-2 { grid-template-columns: 1fr; } }

        .login-box {
            max-width: 400px;
            margin: 100px auto;
            background: #1a1a2e;
            border: 1px solid #2a2a4a;
            border-radius: 16px;
            padding: 40px;
            text-align: center;
        }
        .login-box h1 { color: #00d4ff; margin-bottom: 8px; }
        .login-box p { color: #666; margin-bottom: 24px; font-size: 14px; }
        .login-box input {
            width: 100%;
            padding: 14px;
            background: #0f0f23;
            border: 1px solid #2a2a4a;
            border-radius: 10px;
            color: #e0e0e0;
            font-size: 15px;
            margin-bottom: 16px;
        }
        .login-box input:focus { outline: none; border-color: #00d4ff; }
        .login-box button { width: 100%; padding: 14px; font-size: 15px; }

        .message-content {
            max-width: 300px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        .message-content.deleted { text-decoration: line-through; opacity: 0.5; }

        .tabs {
            display: flex;
            gap: 4px;
            margin-bottom: 20px;
            border-bottom: 1px solid #2a2a4a;
            padding-bottom: 12px;
        }
        .tab {
            padding: 8px 20px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            color: #888;
            text-decoration: none;
        }
        .tab:hover { background: rgba(0,212,255,0.1); color: #00d4ff; }
        .tab.active { background: rgba(0,212,255,0.15); color: #00d4ff; font-weight: 600; }

        .section { display: none; }
        .section.active { display: block; }

        .avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: #2a2a4a;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            color: #00d4ff;
            margin-right: 8px;
            vertical-align: middle;
        }

        .actions { display: flex; gap: 6px; flex-wrap: wrap; }
    </style>
</head>
<body>

<?php if (!$isLogged): ?>

    <!-- TELA DE LOGIN -->
    <div class="login-box">
        <h1>🔐 UniChat Admin</h1>
        <p>Painel de Gerenciamento</p>
        <?php if (isset($loginError)): ?>
            <div class="alert alert-error"><?= sanitize($loginError) ?></div>
        <?php endif; ?>
        <form method="POST">
            <input type="password" name="password" placeholder="Digite a senha de administrador..." required autofocus>
            <button type="submit" name="login" class="btn btn-primary">Entrar no Painel</button>
        </form>
        <p style="margin-top: 20px; font-size: 12px; color: #444;">
            Dica: Use a senha do admin do banco ou "admin123"
        </p>
    </div>

<?php else: ?>

    <div class="container">
        <header>
            <div>
                <h1>🔐 UniChat Admin</h1>
                <p style="color: #666; font-size: 13px; margin-top: 4px;">Gerenciamento de Usuários e Mensagens</p>
            </div>
            <div class="stats">
                <div>👥 Usuários: <span><?= number_format($totalUsers) ?></span></div>
                <div>💬 Mensagens: <span><?= number_format($totalMessages) ?></span></div>
                <a href="?logout=1" class="btn btn-danger btn-sm">Sair</a>
            </div>
        </header>

        <?php if ($msg): ?>
            <div class="alert alert-success">✅ <?= sanitize($msg) ?></div>
        <?php endif; ?>
        <?php if ($err): ?>
            <div class="alert alert-error">❌ <?= sanitize($err) ?></div>
        <?php endif; ?>

        <!-- ABAS -->
        <div class="tabs">
            <a href="#usuarios" class="tab active" onclick="showTab('usuarios')">👥 Usuários</a>
            <a href="#mensagens" class="tab" onclick="showTab('mensagens')">💬 Mensagens</a>
            <?php if ($editUser): ?>
                <a href="#editar-user" class="tab" onclick="showTab('editar-user')">✏️ Editar Usuário</a>
            <?php endif; ?>
            <?php if ($editMessage): ?>
                <a href="#editar-msg" class="tab" onclick="showTab('editar-msg')">✏️ Editar Mensagem</a>
            <?php endif; ?>
        </div>

        <!-- SEÇÃO USUÁRIOS -->
        <div id="usuarios" class="section active">
            <div class="card">
                <h2>👥 Gerenciar Usuários</h2>
                <form class="search-box" method="GET">
                    <input type="text" name="search_user" placeholder="Buscar por ID ou username..." value="<?= sanitize($_GET['search_user'] ?? '') ?>">
                    <button type="submit" class="btn btn-primary">Buscar</button>
                    <?php if ($_GET['search_user'] ?? ''): ?>
                        <a href="painel.php" class="btn btn-warning">Limpar</a>
                    <?php endif; ?>
                </form>
                <div style="overflow-x: auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Usuário</th>
                                <th>Role</th>
                                <th>Status</th>
                                <th>Criado</th>
                                <th>Banido</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $u): ?>
                            <tr>
                                <td>#<?= $u['id'] ?></td>
                                <td>
                                    <span class="avatar"><?= strtoupper(substr($u['username'], 0, 2)) ?></span>
                                    <?= sanitize($u['username']) ?>
                                </td>
                                <td>
                                    <span class="badge badge-<?= $u['role'] === 'admin' ? 'admin' : ($u['role'] === 'vice_admin' ? 'vice' : 'user') ?>">
                                        <?= $u['role'] ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge badge-<?= $u['status'] === 'online' ? 'online' : 'user' ?>">
                                        <?= $u['status'] ?>
                                    </span>
                                </td>
                                <td class="text-muted"><?= date('d/m/Y H:i', $u['created_at']) ?></td>
                                <td>
                                    <?php if ($u['is_banned']): ?>
                                        <span class="badge badge-banned">SIM</span>
                                    <?php else: ?>
                                        <span class="text-muted">Não</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="actions">
                                        <a href="?edit_user=<?= $u['id'] ?>#editar-user" class="btn btn-primary btn-sm" onclick="showTab('editar-user')">✏️ Editar</a>
                                        <?php if ($u['is_banned']): ?>
                                            <a href="?unban_user=<?= $u['id'] ?>" class="btn btn-success btn-sm" onclick="return confirm('Desbanir este usuário?')">🔓 Desbanir</a>
                                        <?php else: ?>
                                            <a href="?ban_user=<?= $u['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Banir este usuário por 30 dias?')">🔒 Banir</a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($users)): ?>
                                <tr><td colspan="7" style="text-align:center; color:#666; padding: 30px;">Nenhum usuário encontrado.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- SEÇÃO EDITAR USUÁRIO -->
        <?php if ($editUser): ?>
        <div id="editar-user" class="section">
            <div class="card">
                <h2>✏️ Editar Usuário #<?= $editUser['id'] ?></h2>
                <form method="POST">
                    <input type="hidden" name="user_id" value="<?= $editUser['id'] ?>">
                    <div class="grid-2">
                        <div class="form-group">
                            <label>Username</label>
                            <input type="text" name="username" value="<?= sanitize($editUser['username']) ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Nova Senha <small>(deixe em branco para não alterar)</small></label>
                            <input type="text" name="password" placeholder="Digite a nova senha...">
                        </div>
                        <div class="form-group">
                            <label>Role</label>
                            <select name="role">
                                <option value="user" <?= $editUser['role'] === 'user' ? 'selected' : '' ?>>User</option>
                                <option value="vice_admin" <?= $editUser['role'] === 'vice_admin' ? 'selected' : '' ?>>Vice Admin</option>
                                <option value="admin" <?= $editUser['role'] === 'admin' ? 'selected' : '' ?>>Admin</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Status</label>
                            <select name="status">
                                <option value="online" <?= $editUser['status'] === 'online' ? 'selected' : '' ?>>Online</option>
                                <option value="offline" <?= $editUser['status'] === 'offline' ? 'selected' : '' ?>>Offline</option>
                                <option value="away" <?= $editUser['status'] === 'away' ? 'selected' : '' ?>>Away</option>
                            </select>
                        </div>
                    </div>
                    <div style="display: flex; gap: 10px; margin-top: 10px;">
                        <button type="submit" name="edit_user" class="btn btn-primary">💾 Salvar Alterações</button>
                        <a href="painel.php#usuarios" class="btn btn-warning" onclick="showTab('usuarios')">Cancelar</a>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>

        <!-- SEÇÃO MENSAGENS -->
        <div id="mensagens" class="section">
            <div class="card">
                <h2>💬 Gerenciar Mensagens</h2>
                <form class="search-box" method="GET">
                    <input type="text" name="search_msg" placeholder="Buscar por ID ou conteúdo..." value="<?= sanitize($_GET['search_msg'] ?? '') ?>">
                    <button type="submit" class="btn btn-primary">Buscar</button>
                    <?php if ($_GET['search_msg'] ?? ''): ?>
                        <a href="painel.php" class="btn btn-warning">Limpar</a>
                    <?php endif; ?>
                </form>
                <div style="overflow-x: auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Autor</th>
                                <th>Tipo</th>
                                <th>Conteúdo</th>
                                <th>Data</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($messages as $m): ?>
                            <tr>
                                <td>#<?= $m['id'] ?></td>
                                <td>
                                    <span class="avatar"><?= strtoupper(substr($m['real_username'] ?? $m['username'], 0, 2)) ?></span>
                                    <?= sanitize($m['real_username'] ?? $m['username']) ?> 
                                    <small class="text-muted">(ID:<?= $m['user_id'] ?>)</small>
                                </td>
                                <td><span class="badge badge-user"><?= $m['type'] ?></span></td>
                                <td>
                                    <div class="message-content <?= $m['deleted_for_all'] ? 'deleted' : '' ?>">
                                        <?= sanitize(substr($m['content'], 0, 80)) ?><?= strlen($m['content']) > 80 ? '...' : '' ?>
                                    </div>
                                </td>
                                <td class="text-muted"><?= date('d/m/Y H:i', $m['created_at']) ?></td>
                                <td>
                                    <?php if ($m['deleted_for_all']): ?>
                                        <span class="badge badge-banned">Deletada</span>
                                    <?php else: ?>
                                        <span class="badge badge-online">Ativa</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="actions">
                                        <a href="?edit_message=<?= $m['id'] ?>#editar-msg" class="btn btn-primary btn-sm" onclick="showTab('editar-msg')">✏️ Editar</a>
                                        <?php if ($m['deleted_for_all']): ?>
                                            <a href="?restore_message=<?= $m['id'] ?>" class="btn btn-success btn-sm" onclick="return confirm('Restaurar esta mensagem?')">🔄 Restaurar</a>
                                        <?php else: ?>
                                            <a href="?delete_message=<?= $m['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Remover esta mensagem?')">🗑️ Deletar</a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($messages)): ?>
                                <tr><td colspan="7" style="text-align:center; color:#666; padding: 30px;">Nenhuma mensagem encontrada.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- SEÇÃO EDITAR MENSAGEM -->
        <?php if ($editMessage): ?>
        <div id="editar-msg" class="section">
            <div class="card">
                <h2>✏️ Editar Mensagem #<?= $editMessage['id'] ?></h2>
                <form method="POST">
                    <input type="hidden" name="message_id" value="<?= $editMessage['id'] ?>">
                    <div class="form-group">
                        <label>Conteúdo da Mensagem</label>
                        <textarea name="content" rows="6" required><?= sanitize($editMessage['content']) ?></textarea>
                    </div>
                    <div class="form-group">
                        <label>Informações</label>
                        <p class="text-muted" style="font-size: 13px;">
                            Autor: <strong><?= sanitize($editMessage['username']) ?></strong> (ID: <?= $editMessage['user_id'] ?>) | 
                            Tipo: <?= $editMessage['type'] ?> | 
                            Data: <?= date('d/m/Y H:i:s', $editMessage['created_at']) ?>
                        </p>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="submit" name="edit_message" class="btn btn-primary">💾 Salvar Mensagem</button>
                        <a href="painel.php#mensagens" class="btn btn-warning" onclick="showTab('mensagens')">Cancelar</a>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>

    </div>

    <script>
        function showTab(id) {
            document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.getElementById(id)?.classList.add('active');
            // Atualiza URL hash
            window.location.hash = id;
        }

        // Ativa aba baseada no hash da URL
        if (window.location.hash) {
            const hash = window.location.hash.substring(1);
            if (document.getElementById(hash)) {
                showTab(hash);
            }
        }
    </script>

<?php endif; ?>

</body>
</html>
